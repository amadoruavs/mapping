# ISM — standalone mapping package

## Run it

Edit `INPUT_REPO` and `OUTPUT_DESTINATION` at the top of **run.py**, then:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py
```

From this existing ADM workspace, its installed environment also works:

```sh
/Users/avneh/Code/ADM/.venv/bin/python /Users/avneh/Code/ADM/ISM/run.py
```

Use a new or empty output directory. The runner preserves existing output and
refuses to overwrite it. Input means a local photo directory, not a Git URL.
It reads image files directly in that directory; it does not recursively scan
nested repositories. The tested input is 306 photos with usable GPS metadata.

Optional path overrides:

```sh
python3 run.py --input /path/to/photos --output /path/to/new-output
python3 run.py --compile-only
python3 run.py --self-test
python3 run.py --photo-preview --input /path/to/photo.jpg --output /path/to/new-preview
```

## Separate visual runner

Edit `VISUAL_PROCESS = True`, input/output paths and preview width at the top of
`run_visual.py`, then run `python3 run_visual.py`. Open the printed
`visual_process/process.html` path in a browser; it refreshes during processing.
`VISUAL_PROCESS = False` or `--no-visual` calls the base runner directly.
The visual runner shares `run.py`'s SETTINGS but has separate path defaults.

The gallery records selection, representative SIFT features and verified matches,
alignment footprints, the first frame of each FSR shader pass, three recursive
generated views, the neutral map, presentation stages, flat-plane tracing and
grading. Diagnostic flow/depth resources are labeled as such; they are not
photographs or measured elevation. Full-map stages include a matching detail crop.
Previews are bounded to 1400 px by default; it does not save every generated image.
Readbacks and exports add time, so use `run.py` for base speed measurements.

## Requirements and package contents

- Apple silicon with Metal/MPS and ray tracing; tested on Apple M4 Pro, 24 GB.
- macOS 26 or later: the translated FSR shaders require Metal 4 coherent access.
- Xcode Command Line Tools (`xcode-select --install`) for the Objective-C host bridge.
- Python 3.12 and the exact dependency versions in `requirements.txt` were tested.
- Keep this **whole ISM folder** together when moving it. It has no runtime
  dependency on the parent ADM checkout, the downloaded FidelityFX SDK, glslang,
  SPIRV-Cross or the system `metal` command-line compiler.

| File | Purpose |
|---|---|
| `ISM.metal` | Sole shader source: all 84 ADM and translated AMD FSR compute kernels |
| `run.py` | Editable paths/settings, fresh-process launcher, wall timer, validation |
| `run_visual.py` | Separate optional gallery runner; True/False flag at top |
| `runtime/adm/` | CPU orchestration, metadata, SIFT/RANSAC, geography and codecs |
| `runtime/ADMMetal.m`, `runtime/FSRMetal.m` | Native Metal/MPS resource and dispatch bridges |
| `runtime/fsr_manifest.json` | FSR resource bindings, constant layouts and provenance |
| `runtime/bundle_manifest.json` | Shader inventory and source hashes |
| `runtime/LICENSES.txt` | Retained third-party notices |
| `build/` | Automatically compiled host libraries and validation reports |
| `tests/` | CPU/GPU agreement, FSR, ray tracing and relocation checks |

A `.metal` source is GPU code, not a macOS application: it cannot open a photo
directory, decode JPEG/PNG, call OpenCV, or launch itself. ISM therefore puts **all
custom GPU shader code in one file** and includes the small host runtime needed
to execute the end-to-end pipeline. MPS matrix multiplication and factorization
remain Apple's framework implementations. The full application is not a single
GPU kernel or entirely GPU-only.

`ISM.metal` compiles once per process into one Metal 4 library shared by ADM and
FSR. FSR helper symbols are namespaced with stable exported kernel names. The
first run also compiles two native host libraries with clang; they are cached
under `build/`. Driver shader caching may shorten later initialization. This
machine has no standalone `xcrun metal` utility; runtime shader compilation is
tested and does not require it.

## Exact default pipeline

`alignment_max_iterations=600` in run.py is the GPU alignment limit. The existing
convergence thresholds remain unchanged: accepted objective improvement below
`1e-6 * max(old,1)` or normalized parameter-step norm at most`3e-7`, subject to
successful factorization and low damping. The GPU freezes the accepted result
when convergence is detected; the host stops submitting after the current batch
of four iterations, so at most three additional iterations are encoded.
`registration_report.json` records budget, active and encoded iteration counts.
The generic runtime default remains60; both ISM runners use run.py's600 setting.

Native alignment now writes and flushes `[alignment]` progress after each existing
four-iteration GPU synchronization. Lines include active/budget/encoded iterations,
objective, accepted/rejected steps, damping and elapsed seconds. Follow them with
`tail -f /path/to/output/run.log`. This adds no extra GPU synchronization and
does not change convergence. Processes started before this update retain their
already-loaded native library and will still print only their final report.

Latest user edit: run.py now starts registration at **1280 px**, with
`alignment_budget_mb=1024` (generic runtime default512). Recovery keeps at least
1280px and uses the more sensitive .01 SIFT detector. The historical640px first
pass below describes the saved benchmark. All564photos connected in
`benchmarks/maps_recovery_v3/match_graph_report.json` with11verifiedbridges;
that run then hit the former512MiB workspace limit. The budget increase and
1280px first pass have not received a full E2E rerun, at the user's request.

1. Select originals, decode/hash them, and read metadata. `skip_first=0`.
2. GPS centers select candidate pairs. CPU SIFT at width 640 extracts features;
   Metal/MPS matches descriptors; CPU RANSAC verifies the pairs.
3. Metal robust planar homography alignment and MPS Cholesky solve; CPU geographic fit.
   If initial matches are disconnected, retry cross-group GPS/sequence neighbors
   at width 1280, up to 256 pairs. Accepted edges retain at least 30 RANSAC inliers,
   a 25% inlier ratio and spatial spread in both images. Recovery uses a more
   sensitive SIFT detector (.01 contrast threshold versus .025 normally).
   Coordinates are converted back into the initial registration grid.
   Singular fits and transforms crossing
   an image's projective horizon are rejected. `match_graph_report.json` records
   recovery; remaining disconnected groups stop with an explicit filename list.
4. AMD FSR Frame Interpolation 1.1.3 from SDK 1.1.4 generates recursive midpoints.
   With 306 originals, 305 valid adjacent pairs and two levels: **915 unique
   generated views, 1,221 compositor inputs**. Registration uses originals only.
5. Coherent source selection builds a 6,500 × 4,394 neutral map for this benchmark.
6. Current SIYI defaults: chroma-only noise cleanup (strength .7), Lanczos 2×,
   positive detail **.65**, Lab CLAHE (clip 2, grid 8×8) blended at **35%**,
   fine sharpening (sigma .45, weights 1.15/−.15), identity global contrast.
   NLM and final FSR spatial upscaling remain disabled.
7. The Metal triangle ray tracer evaluates the **flat map plane** selected by the
   user. No intensity-derived terrain or invented building geometry is added.
8. The fused `siyi_low_light` cinematic grade and final 2× PNG export.

The 128 MiB coherent budget is working memory, not a saved cache. FSR keeps two
real and three generated images. Two compositor traversals require 1,830 frame
generation calls for 915 unique views; synthetic images are not written to disk.
The normal runner neither writes nor reuses a feature-match cache.

## Pleasant color adjustment

`run.py` currently selects `presentation_profile='siyi_low_light'` and
`color_grade='siyi_low_light'`, tuned from IMG_0556.jpg at the user's request.
It adds +.08 stops exposure, .035 shadow lift, subtle RGB balance 1.05/1/.94,
.02 luma contrast and restrained warm highlights. Chroma cleanup smooths color
speckle while retaining each pixel's luminance; it is not the removed NLM pass.
Fine-detail gain and CLAHE are lower because the sample contains visible noise.

To use the 306-photo benchmark appearance, set `presentation_profile='standard'`
and `color_grade='pro_camera'`. That standard profile uses the values below.

This is a small revision of the prior sunset presentation:

| Control | Previous | ISM |
|---|---:|---:|
| Grade exposure | −.06 stops | 0 |
| Grade luma contrast | .12 | .04 |
| Gentle shadow lift | 0 | .025 |
| CLAHE blend | 100% | 75% |
| Final contrast multiplier/offset | 1.05/−2 | 1.02/−1 |
| Positive detail | 1.3 | 1.3 |
| White shoulder reduction | .3 | .3 |
| Vibrance reduction | .1 | .1 |

Warm/cool tints are weaker, especially on neutral pavement and roofs. The shadow
lift leaves pure black unchanged. White/vibrance controls live **inside**
`runtime/adm/cinematic_grade.py::PRESETS['pro_camera']`; there is no extra
after-grade white compression. No grain, vignette or second sharpening stack.
The aim is open shadows and less harsh local contrast, while retaining road detail.

## Timing and outputs

`timer()` in run.py uses `time.perf_counter()`. `timing.json` measures the complete
fresh worker process: imports, runtime initialization, raw input processing,
GPU work, PNG encoding and export. This is the end-to-end number. Internal
stage times exclude some startup/teardown. Compilation checks, visual preview
generation and tests are reported separately. CPU RSS is not total GPU memory.

Completed on the Apple M4 Pro / 24 GB, with fresh mapping and no match cache:

| Measurement | Time | Scope |
|---|---:|---|
| ISM standard/pleasant, 306 original 640×640 photos | **116.628 s** | Full process; 915 generated views, 1221 compositor inputs; `benchmarks/e2e_306_pleasant/timing.json` |
| SIYI 3840×2160 photo → 7680×4320 presentation | **1.123 s** | Single-photo sharpening, plane trace, grade and PNG export; no registration/mapping |
| Full-size SIYI FSR identity check | **.383 s** | Same photograph used as both parents; exact output on this fixture |

The 116.628 s benchmark predates the SIYI defaults, fixed-point Gaussian update
and disconnected-graph recovery. It is evidence for that saved revision, not a
timing promise for the current settings or a 564-photo 4K flight. The SIYI photo
preview also predates the Gaussian rounding correction. Saved configs accompany
these reports; visual previews are in `benchmarks/siyi_photo/`.

Validation includes relocation, graph recovery,
degenerate-match rejection, FSR identity/translation, ray tracing, CPU/Metal
agreement and exact presentation pixel preservation with visualization enabled.
The added faint-texture recovery regression repeats the same inputs and verifies
identical accepted correspondences and transforms. Read `build/validation.json`
for the current complete suite result.
On the SIYI numerical fixture the full presentation differs from OpenCV by mean
.032/255 and maximum 3/255; the new chroma and grade fixtures match exactly.
Gaussian arithmetic now follows OpenCV's fixed-point weights and uses half the
previous temporary-buffer bytes. Full photographic CPU parity is not bit-exact.

| Output | Meaning |
|---|---|
| `map_neutral.png` | Native mapping result |
| `map_graded.png` | Enlarged final presentation |
| `map_geometry.json`, `image_to_map.npy` | Native georeferencing/transforms |
| `presentation_geometry.json`, `image_to_presentation.npy` | Correct enlarged-output geometry |
| `timing.json`, `run.log` | Full-process time and progress/error log |
| `report.json`, `matching_report.json`, `registration_report.json` | Mapping diagnostics |
| `interpolation_report.json` | Actual FSR counts and timing |
| `presentation_report.json`, `grading_report.json`, `raytracing_report.json` | Final processing settings and times |

## Practical limits

This is a planar mosaic, not a 3D reconstruction. The ray tracer supports real
triangle intersections and up to two diffuse bounces, but a flat plane produces
uniform illumination and preserves the existing photographed shadows. Building
and terrain shadows need measured geometry. FSR uses homography-derived motion
and assumed flat depth; optical-flow assistance is disabled. Interpolation and
enlargement do not add new measured ground detail or recover clipped highlights.

Set `altitude_agl_m` for your actual height above ground. The user's current
`run.py` value is 51.816 m (170 ft); the saved 306-photo benchmark used 60 m.
EXIF GPS altitude is above sea level, so it is not substituted for flight AGL.
The runner requires GPS metadata. Use the underlying packaged pipeline's explicit
`--allow-local` mode only when local, ungeoreferenced output is intentional.
Very large photos or final images can exceed memory limits: FSR is bounded to
64–4,096 pixels per axis and a 1024 MiB resource estimate in `run.py` (the generic
runtime default remains 512 MiB). This estimate is per FSR frame, not total RSS.
Presentation is capped
at 160 million pixels. The default output allowance is 768 MiB.

Separate FSR renders have previously shown small pixel differences despite
identical geometry. Numerical parity tests and fresh benchmark checks are listed
with their practical limits; do not assume every fresh render is bit-identical.

## Provenance

AMD FSR SDK revision `c6efa6bf7f2027b3ec94f28578bb5965eabb9e55`. The included
translated pass equations are unchanged; packaging namespaces their helpers and
renames exported entries. Original licenses are in `runtime/LICENSES.txt` and
AMD notices are also embedded in the shader.

Metal's host/library split follows [Apple's Metal library documentation](https://developer.apple.com/documentation/metal/metal-libraries).
The ray tracer follows [Apple's intersection API](https://developer.apple.com/documentation/metal/ray-tracing-with-acceleration-structures).
