# ADM implementation memory

## ISM standalone package and SIYI settings (2026-09-15 UTC)

CRITICAL latest600-iteration full-flight audit: user's `final_test` failed after
1094.049629s wall,913.194584s alignment,600iterations(401accepted/199rejected).
Finalobjective13140.9336; finalacceptedgain11.80859 vs threshold.0131527(897.8x).
Finalstep.004898 vs3e-7(16326.7x). Reportedmedian.0028486px/p95.01239065px
MUST NOT be presented as good alignment accuracy: inspection of transforms.npy
shows523/564projected footprints below1% of original registration-image area;
medianarea ratio2.92155e-6, no horizon folds. Most images collapsed in scale,
artificially reducing the forward mapped-coordinate objective. Rejected trace
steps include NaNs/huge norms. More iterations alone cannot establish valid map
geometry. Need scale/shape constraints or a non-collapsing residual/initialization
before accepting this solution. No map generated; no fixes/reruns made in audit.

Live diagnostics update: user asked to see current worker36589's activity. macOS
sample showed `adm_align -> adm_sync -> MTLCommandBuffer waitUntilCompleted`;
IORegistry reported100%device utilization. This establishes alignment/GPU activity,
not exact iterations or guaranteed forward progress. Added native stdout+flush
progress after existing4-iteration sync:active/budget/encoded counts,objective,
accepted/rejected,damping,elapsed. No extra synchronization/changed math.
Source update is for future processes; the already-running worker keeps its old
loaded dylib. Sample saved `ISM/build/worker_36589_sample.txt`. No restart requested.

Latest change: user requested a600-iteration cap with early stopping. Added
`alignment_max_iterations` (generic Config default60, ISMrun.py600, validated
integer1..600), passed pipeline→registration→GPUsolver; previous200 API ceiling
raised to600. Existing MSL convergence equations and four-iteration host batches
are unchanged. Self-test26tests passed. The noisy3-image alignment regression
converges after5 active/8encoded iterations with cap600, with bit-identical
transforms to cap60. No new full mapping run was launched.
The user's previous `final_test` run failed after283.199s at60iterations:
all564connected,19076edges,541282768planned scratchbytes,median.2792px/p951.0052px.
Last accepted objective306397.28→285305.91(6.9% improvement), followed by a
rejected trial: it had not plateaued. More iterations permit further optimization;
full-flight convergence with600 has not yet been verified.

Final handoff: user stopped further runs and will test themselves. Nothing is
running. `maps_recovery_v3` connected all564photos with11verifiedbridges after
lowering ONLY recovery SIFT detection contrast to.01;266–447inliers/bridge.
It then hit512MiB alignment workspace guard at193.877s. Added configurable
alignment_budget_mb(default512generic,1024inISMrun.py;128..2048validated),
propagated through pipeline/registration/GPUsolver. Syntax checked after this
last change; no further benchmark launched. Full564E2E remains unverified.
User independently changed run.py registration_width to1280; PRESERVED that edit.
Faint-texture recovery test repeats with identical matches/transforms (5CPU
graph tests pass; prior23-testfullsuite predates finaldetector/budgetupdates).

`ISM/` contains one `ISM.metal` with 84 exported kernels and a portable host
runtime. All ten translated FSR passes share that Metal 4 library with ADM.
The entire folder is required; a shader cannot perform file IO or CPU SIFT.
`run.py` exposes paths, SETTINGS and a full-process timer. Preserve the user's
edits: currently input `/Users/avneh/Downloads/maps`, output `final_test`, AGL
51.816 m (170 ft). The user chose the IMG_0556 settings as run.py defaults.
`run_visual.py` is separate, with VISUAL_PROCESS=True/False and a saved/live HTML
gallery. It shares SETTINGS but has separate path defaults. Its presentation
observation hooks are pixel-identical in tests; full visual flight smoke pending.

- SIYI profile: chroma-only edge-aware cleanup .7 (preserves per-pixel luma),
  Lanczos2x, positive detail .65, CLAHE blend .35, fine gain .15, final contrast
  1/0. Grade exposure+.08, shadow lift .035, luma contrast .02, RGB balance
  1.05/1/.94, tiny warm highlights. No NLM or final FSR spatial upscale.
- Standard profile remains available: detail1.3, CLAHE blend.75, fine.35,
  contrast1.02/-1; pro_camera exposure0, contrast.04, shadow lift.025 and weaker
  tints. Both use the nondestructive white shoulder .3/vibrance.1 inside grade.
- Gaussian now matches OpenCV's error-diffused fixed-point weights with a
  uint16 temporary (half prior bytes). This fixed CLAHE amplification of blur
  rounding: SIYI synthetic full recipe mean .032/255, max3, versus former max25.
  Chroma and grade fixtures exact. 23 package tests passed after these changes,
  including real FSR identity/translation, ray tracing, standalone relocation,
  connection recovery, invalid pair rejection and visual observation parity.
- Saved standard ISM306 benchmark: `ISM/benchmarks/e2e_306_pleasant`, full wall
  116.628144875s;306originals/915generated/1221inputs; matching55.4188s,
  alignment7.43384s, map/presentation/export38.2085s; RSS2049507328bytes.
  This PREDATES SIYI defaults, fixed-point Gaussian and match recovery. Its
  shader SHA252a4db148e8af4c36fb13188e60ba4fd8fd0f76ac298e186d0bfcd4b0a3ee16.
- `ISM/benchmarks/siyi_photo`: full3840x2160sample to7680x4320 presentation
  1.122878s inclPNG, FSR fullsize identity .383071s exact. Not a flight/mapping
  benchmark; predates Gaussian correction. Original folder renamed to `maps`.
- User reported disconnected graph on5644Kphotos. Added `adm/match_graph.py`:
  only disconnected graphs retry verified cross-group GPS/sequence pairs at1280,
  retaining .70ratio/30inliers/25%ratio/spatialcoverage requirements; convert
  matches back to original640grid. Bounded256attempts/16imagefeatureLRU. Reports
  filenames/components and never creates GPS-only edges or silently drops frames.
  Singular/horizon-crossing pair transforms now rejected before projection.
  Reproduction before that guard also hit `Projection intersects horizon` after
  86.395s; `/maps` retained564 and proposed109279pairs. Corrected full run is
  `ISM/benchmarks/maps_recovery_v2`; do not assume success until its report exists.

See `ISM/GUIDE.md` for current operation and qualified benchmarks. `LeanADM/`
remains unchanged. Old sections below describe their saved historical revisions.

## Latest revision: natural sunset, no NLM (2026-09-15 UTC)

User explicitly removed NLM, reduced positive detail to 1.3, moved white/vibrance
controls into `pro_camera`, requested natural late-sunset grading and ray tracing,
then a fresh timed run. Current sequence: register original photos -> actual FSR
frame generation -> mapping -> Lanczos 2x -> positive detail 1.3 -> CLAHE -> fine
sharpen / contrast -> triangle ray tracing -> fused cinematic `pro_camera` grade.
The separate `LeanADM/` backup is unchanged. Final FSR spatial upscale stays off.

- `adm/cinematic_grade.py::pro_camera_grade` is now the CPU reference for the
  revised preset; `post_cinematic_grade` is the fused Metal version. Exposure
  -.06 stops, luma contrast .12, mild cool shadows / warm highlights with reduced
  tint on neutral colors, white reduction .3 and vibrance reduction .1 inside the
  preset. White reduction controls shoulder slope (white maps to .9475 before
  exposure), rather than the earlier destructive .7 endpoint. Hue-preserving
  gamut compression. No extra grade sharpening, vignette, bloom or grain.
- NLM remains available for historical numerical tests but is not called by
  `enhance` or the current benchmark. Likewise `finish_tone` is historical;
  `write_presentation` no longer calls it. Legacy config white/vibrance knobs
  override the pro_camera preset rather than adding a second pass.
- Real ray tracing: `adm/raytracing.py`, `shaders/raytracing.metal`, and the
  `adm_trace` native bridge build a Metal triangle acceleration structure and
  trace primary, solar-disk visibility and cosine-weighted diffuse bounce rays.
  At most two diffuse bounces; deterministic samples, bounded grid <=512x512,
  max 1M triangles / 512 MiB acceleration scratch+structure. The Python `trace`
  API accepts explicit registered triangle soup/materials. This dataset has no
  measured elevation: `relight_map` supplies only two flat-plane triangles,
  128x87 grid, 8 samples, artistic sun elevation 3 / azimuth 255. Flat-plane lighting
  preserves pixels exactly; it adds no building/terrain shadows or new detail.
  Do not describe it as recovered 3D geometry or physically relit photography.
- Updated shared bridge fixes `adm_device` string lifetime (device name had
  sometimes been empty); all shaders recompiled. 58 regression tests passed,
  including CPU/Metal grade parity (exact test fixture), revised OpenCV sharpen
  parity (mean .04078/255, max7 BGRA fixture), directional occlusion against real
  test geometry, repeated-ray determinism and flat-map pixel preservation.
- Presentation-only preview `metal_fsr3_sunset_preview` took 3.97762 s including
  decode/export from a saved neutral map. This is not the full-process timing.
  Active config `fsr_experiments/natural_sunset.json`, also `full_pipeline.json`.
  Fresh 306-image benchmark completed in `metal_fsr3_sunset_e2e`:
  **109.706055375 s full-process wall**, 10.29394 s under 120; no matching cache.
  All 306 retained, 915 virtual /1221 inputs, 305 adjacent pairs, no skipped pairs.
  Prep15.0628s, matching50.6148s, alignment7.4252s,
  FSR+mapping+neutral export32.4658s, sharpening/reports.6581s (kernels.6561s),
  ray tracing.03041s, grade.03239s /grade+PNG3.03868s, startup overhead.41035s.
  Peak process RSS 1.976 GiB (not total GPU memory), saved pipeline bytes248606214.
  Original306 transforms exactly equal LeanADM; all 42 frozen source/config
  files unchanged during the benchmark. Source/config hash manifest:
  `fsr_experiments/sunset_source_manifest.json`; validation `sunset_validation.json`.
- `fsr_experiments/sunset_e2e_summary.json` consolidates timings and checks.
  `metal_fsr3_sunset_e2e/{map_graded.png,overview.png,road_comparison.png}` are
  the actual fresh-run result and previews. The post-benchmark stage replay
  reproduced its full graded map exactly (SHA25684cfe7a037235696d5172265e4f4147e4a803636e4f1fac0f52f859722236c61).
  Same137961-pixel road mask, area-filtered to native scale: texture RMS
  LeanADM 2.31898 /previous grade.49926 /new grade2.44360; gradients20.0651 /
  3.22221 /22.0631. Local contrast proxy, not added real resolution.
  Remaining limitation: preserved global contrast clips 8.70% of bright-road
  pixels in at least one channel before grading; grade cannot recover this.
  FSR neutral map across separate runs is not bit-identical despite identical
  transforms (mean BGRA abs difference .05104/255,max201); do not claim exact
  FSR raster repeatability. Final full-map stage replay itself is exact.

## Completed previous full run and detail-loss audit

`metal_fsr3_lanczos_toned_e2e` completed all 306 originals in **120.36548s** wall
time, 0.36548 s over two minutes (internal 119.79328 s excludes process overhead).
915 unique generated views / 1221 compositor inputs, all 305 pairs, no match-cache
reuse. Original transforms exactly match saved LeanADM. Prep15.429s,
matching53.147s, alignment7.402s, composition/presentation/export43.815s.
NLM/sharpen4.324s; grade/export4.864s. Peak process RSS1.974GiB is not total GPU
unified memory. Frozen41-file source/config hashes were unchanged during that run.

Its post-benchmark full-map stage replay reproduced the saved final pixels
exactly. Same fixed bright-road crop/mask: neutral texture RMS 2.0865 -> NLM1.6429
(-21.3%), pro_camera1.9458 -> old white/vibrance finish.4993 (-74.3%). Contrast
before grade clipped8.65% of pixels in at least one RGB channel on that mask.
These are local contrast proxies, not recovered-detail/overall quality scores.
The assistant's former white endpoint .7 implementation caused severe highlight
flattening; it was not equivalent to a conventional Whites -30 slider.
Reports: `quality_audit/stage_audit.json` and `quality_audit/road_stages.png` in
that old run. `fsr_experiments/e2e_lanczos_summary.json` contains all checks/timing.

## Historical presentation change: no final FSR upscale

User requested whites -30%, vibrance -10%, then explicitly removed FSR **before
sharpening**. FSR frame generation is retained. Current order: original registration
-> FSR interpolation -> mapping -> NLM -> Lanczos 2x -> detail/CLAHE/fine sharpening
-> pro_camera grade -> white/vibrance reduction. Current presentation defaults:
FSR passes 0, Lanczos scale 2. Grading adjustments default to zero generally;
the active benchmark configs set .3/.1.

`output/killerofmaps/metal_fsr3_lanczos_toned/map_graded.png` is the new 13000x8788
result, generated from `metal_fsr3_full/map_neutral.png`. It took **9.12687 s**
for presentation and export only, with **4.22061 s** sharpening (NLM 3.71980)
and 4.48939 s grading/export. No full registration/frame-generation benchmark
was rerun, so do not call this a 9-second end-to-end pipeline or reuse 143.6 s
as a measurement of the new settings.

White reduction uses a monotone highlight curve above .5 luminance, mapping
neutral white to .7 at reduction .3; it does not recover already clipped detail.
Vibrance scales chroma by 1-reduction*(1-HSV saturation). Both have Metal and
CPU-reference implementations. Five presentation hardware tests pass, including
the new tone parity/monotonicity/alpha test. The changed NLM reflection arithmetic
also passed parity tests. All image dimensions, projection and transparency are
retained with a separately correct presentation pixel transform.

Current config: `fsr_experiments/full_pipeline.json` and `no_fsr_upscale.json`.
Earlier config preserved as `full_pipeline_fsr_upscale_reference.json` and in
the original run's resolved config. Current previews: `comparison.png` (LeanADM,
previous enhanced, updated) and `road_detail_comparison.png` beside the new map.
`adm.presentation.write_presentation` now supports reusing an existing neutral
map; `experiment_fsr.py presentation_map --config ... --output ...` runs that path.


## Current FSR experiment (2026-09-15 UTC)

The lean baseline below remains the validated non-FSR reference. The user asked
for this experimental order: originals -> registration + FSR interpolation ->
mapping -> FSR upscale -> supplied NLM/Lanczos/detail/CLAHE/sharpen recipe ->
supplied cinematic grade. See `docs/FSR_PIPELINE.md` for implementation and evidence.

- Actual AMD Frame Interpolation 1.1.3 from SDK v1.1.4, revision
  `c6efa6bf7f2027b3ec94f28578bb5965eabb9e55`, now executes on Metal. Unmodified
  GLSL is compiled by glslang, optimized by spirv-opt, translated by SPIRV-Cross
  to MSL 4.0, and compiled at runtime. Requires macOS 26 for coherent textures.
  It uses game motion derived from ADM homographies and assumed constant flat
  depth (60 m in this run); optical-flow assistance is disabled. Never call the
  earlier custom `virtual_views.py` blend AMD FSR frame generation.
- `FSRViews` runs after original registration. For the 306-image benchmark all
  305 adjacent pairs pass; levels=2 creates 915 unique generated views and 1,221
  compositor inputs. Zero synthetic matching constraints. A 2-real/3-generated
  image cache means the two compositor traversals execute 1,830 generation calls.
  No generated-photo files or match cache are saved.
- Final upscale uses FSR1 EASU, followed by the user's supplied recipe. The first
  complete run uses FSR 2x then Lanczos scale 1 (2x total). An optional question
  about 2x versus 4x total was unanswered; 2x was stated as the first timed-run
  assumption. Do not claim the user explicitly chose it. Final presentation is
  bounded to 160 million pixels.
- NLM, fixed-point Lab conversions, Lanczos, CLAHE, Gaussian/detail/contrast and
  global `pro_camera` grading run on Metal. Other presets/regions remain CPU.
  Codecs, SIFT/RANSAC/geography and FSR adapter motion/alpha preparation still use
  CPU; this is not an entirely GPU-only program. `presentation_geometry.json`
  describes the enlarged graded map separately from neutral `map_geometry.json`.
- NLM optimization reuses horizontal distance sums; textured/smooth/flat tests
  are pixel-identical to the retained first Metal implementation. On a real
  1280x1280 FSR-upscaled photo NLM improved 1.32546 -> .20624 s (6.4x); entire
  sharpening .21302 s, grading .00705 s. CPU-reference sharpening difference
  mean .07584/255, p99 2, maximum 9; after grade mean .20615, p99 4, maximum 30.
  Therefore close CPU agreement, not bit-identical CPU parity. Hardware tests
  also verify actual FSR identity/translation and Pillow blur/grade parity.
- Completed fresh run: `output/killerofmaps/metal_fsr3_full`, **143.59494 s** for
  all 306 photos, 11,254 accepted edges, 915 virtual views. Preparation 15.352 s,
  matching 66.896 s, alignment 7.552 s, composition/presentation/export 53.275 s.
  Neutral map 6500x4394, final graded map 13000x8788. FSR final upscale .094 s;
  sharpening 14.148 s (NLM 13.744); grade/export 4.717 s. It missed 120 s.
- The user then asked to see this result compared to saved LeanADM. Side-by-side
  overview and matching detail crops are at
  `output/killerofmaps/fsr_experiments/comparison_lean_fsr3/{overview,detail_crops}.png`.
  Visually the requested combined enhancement is over-sharpened/high-contrast,
  with halos and loss of bright pavement texture. No overall quality win proven;
  do not attribute the combined grade/sharpen change specifically to FSR.
- `LeanADM/` is a separate clean non-FSR backup containing source, config and
  the saved 83.2055 s 306-photo benchmark map/reports. User explicitly said no
  need to rerun this backup; it was not separately validated.
- Remaining optimization investigation: 30-pair FSR profile .57348 s, split
  upload .01575, CPU motion .17354, shader dispatch/read .16895, CPU alpha .21528.
  No native motion/alpha adapter kernels implemented yet. A cheap exact reflection
  arithmetic optimization was added to NLM after the 143.6 s run; that run's
  timing does not include the new change. No further full benchmark completed.


## Current revision: lean pipeline (2026-09-14 evening)

This section supersedes the historical inspection below. See `docs/LEAN_PIPELINE.md` for implementation details, measurements, and artifact links.

- CLI now defaults to `png`: one neutral map, geometry/transforms and small reports. Match caching is optional via `--cache-matches` or `--resume`; diagnostic profile retains it. Corner dumps, support PNGs, lighting, GPS leave-one-out/heading diagnostics, and post-registration footprint-index exports are omitted from the normal PNG path. Full-pose corner checks used for actual matching are retained.
- Vector exports actually bypass compositing and save `project.json`. Config() still defaults to diagnostic for programmatic compatibility; CLI overrides it. Normal coherent output uses 8 rather than 12 primary full-resolution bytes/pixel by omitting support arrays. Diagnostic rendering still exposes coverage/source IDs.
- Matching removes per-descriptor Python DMatch construction, unused square roots and GPS-mode native-coordinate projections. Match settings/candidates are unchanged. `matching_report.json` separates features/upload, descriptor matching, verification/bookkeeping, and cache/diagnostic export time.
- Solver remains one C ABI operation with GPU numerical work, but checks convergence between four-iteration command batches. Actual encoded iterations are reported separately from the maximum budget. At most three frozen iterations remain within the final batch. Cache identity now includes bridge and registration source.
- Fresh full-process timings: SIYI 9.55985 s (previous 30.00013); Archive 9.11155 s (previous 33.63460); 306-image 128 MiB profile 83.20550 s (previous 119.48827). All neutral BGRA pixels and image-to-map transforms are exactly identical to saved baselines. New directories are `metal_lean`, with sibling `metal_lean_timing.json` and `evaluation_lean/comparison.json`.
- New output sizes: SIYI 64.31 MiB, Archive 47.37 MiB, 306 images 52.73 MiB. 306-image internal times: preparation 15.604 s; SIFT/upload 6.996 s; descriptor matching 43.173 s; verification/bookkeeping 7.175 s; alignment/geography 7.398 s; composition/exports 2.395 s. Alignment encoded 12 iterations (9 active) rather than 60.
- Crispness comparison now area-filters minification before geographic warping and uses the exact shared eroded coverage mask. ADM/ODM mean-gradient ratios: SIYI .7841 at 5.00 cm/pixel, Archive 1.0663 at 21.64 cm/pixel. Laplacian-variance ratios .4478 and 1.3401. These are edge/texture proxies, not overall quality or resolved-detail ratios. Earlier bilinear-only, separate-footprint sharpness figures overstate ADM and are not interchangeable. Crop figures are in each dataset's `evaluation_lean/crispness_crops.png`.
- Validation: 38 pipeline/GPU tests passed after implementation; two additional comparison tests verify alias filtering and shared-mask/parity behavior. All 40 pass. Preserved source before trimming is `/private/tmp/adm-before-trim-u0369xhm` (temporary, not guaranteed durable). No saved reference datasets or old outputs were deleted.

## Historical inspection before the lean changes

Inspected 2026-09-14 from local source and saved artifacts. The ADM root has no Git repository. The legacy source checkpoint is `checkpoints/full_metal_86s/`; the separate `ODM/` repository is at `1a7134170e6100cade3236486a279d6241f11f99`.

Source snapshot SHA-256: `aacfc4f06387ed28a46cb26be0ac612f5cab0cdc56ed4794c8dea04917009529`. Computed over sorted `adm/*.py`, `shaders/*.m`, and `shaders/*.metal`, concatenating each relative path, NUL, file bytes, NUL.

## Identity and current behavior

- `metal_optimized` is an output directory/profile name, not a module. `--backend metal --gpu-optimized` sets `gpu_alignment`, `coherent_composite`, `compact_outputs`, and `metal_recompute_warps` true.
- ADM is a planar photomosaic with one homography (eight projective parameters) per photograph. It does not reconstruct cameras in 3D, triangulate scene points, estimate depth, or build a mesh. Its optional input heightmap affects lighting, not registration or orthorectification.
- The optimized profile retains visual feature matching. Do not confuse it with the old `metal_fast` GPS-only preview experiment.
- CPU work: selection, image decoding, metadata, OpenCV SIFT/RANSAC, graph setup, geographic fitting, codecs, and reports. Metal/MPS handles exact descriptor matching, iterative homography alignment, coherent source selection, sampling, and supported lighting/cropping.
- The latest source changes include lasso cropping, output budgets/export profiles, buffer lifetime safeguards, and configurable coarse-compositor memory. Older README/GPU documents describe earlier behavior.

## Selection, matching, and geography

Sources: `adm/selection.py`, `metadata.py`, `geometry.py`, `vocabulary.py`, `registration.py`, and `pipeline.py`.

1. Sort supported input image filenames. Hash inputs and exclude configured initial frames, explicit exclusions, unreadable images, exact duplicates, detected blue annotation labels, and near duplicates. Defaults: skip first 7; thumbnail MAE threshold 1.5. Saved comparison configurations set skip-first to zero.
2. Read EXIF/XMP and optional explicit sidecar overrides. Altitude AGL comes from configuration/sidecar, never automatically from EXIF sea-level altitude. Default AGL 30 m is a placeholder; HFOV 81 degrees, nadir pitch, and square-pixel VFOV derivation are assumptions. Unsupported EXIF orientation is rejected.
3. Saved optimized runs use `--gps-centers`: a KD-tree selects potentially overlapping camera-center circles from AGL/FOV plus GPS tolerance (default 5 m). Recorded yaw does not place images. Without this flag, full camera pose predicts footprints and permits geographic corner verification. Explicit local mode uses sequence neighbors (default 6).
4. Resize each image to registration width (default 1400; Archive/killerofmaps use 640). CPU OpenCV SIFT requests 7000 features with contrast threshold .025. Keep descriptors resident on GPU. MPS computes batched descriptor dot products (512 query rows); MSL norms and 32-lane top-two reductions recover exact squared L2 distances with stable index ties.
5. Apply the .70 nearest/second-nearest ratio test (squared threshold .49 on GPU). Require at least 35 ratio matches. CPU RANSAC fits a homography with 2.5 px tolerance; require at least 30 inliers, 25% inlier fraction, and 3.5% source-image convex-hull coverage. Full-pose mode additionally checks geographic disagreement. Refit accepted inliers and retain at most 160 evenly indexed correspondence pairs per edge; edge `n` retains the original inlier count.
6. Four 50x50 mean-centered corner vocabularies are a separate path: predicted-pose rectification, NCC search radius 24, std >=3, NCC >=.8, delta RMSE <=.02, uniqueness margin >.02, geographic support when available. Four accepted corners can supply an edge. In GPS-center mode these checks are diagnostic-only, after SIFT; non-diagnostic profiles skip them. The latest 306-image runs have zero evaluated corners and all 11,254 edges labeled SIFT fallback.
7. After visual alignment, convert registration-space homographies to native image coordinates. GPS-center fitting uses a CPU float64 robust four-parameter similarity to local WGS84 east/north coordinates, with a vertical-axis flip, soft-L1 scale .75 m, and leave-one-out diagnostics. Requires >=3 images, pitch within 5 degrees of nadir, >=3 m center spread, and median residual <= configured GPS tolerance. GPS establishes scale/north; these residuals are not independent survey accuracy.

## GPU alignment

Sources: `adm/gpu_alignment.py`, `shaders/alignment.metal`, `shaders/ADMMetal.m::adm_align`.

- Anchor image is index N//2. Initialize all homographies by greedily extending the connected graph using the largest-inlier-count crossing edge. Reject disconnected graphs instead of dropping frames.
- Normalize coordinates by registration width. Upload eight float32 homography parameters per image, correspondences, ownership, edge lookup, and incidence arrays. Anchor parameters remain fixed through the normal equations.
- Default 60 iterations, allowed 1..200. One C ABI call encodes the whole budget into one command submission: analytical Jacobians/coordinate-wise soft-L1 weights; per-edge Hessian/gradient blocks; normal-matrix assembly; MPS Cholesky factorization/solve; trial cost reductions; device damping/acceptance/commit.
- Objective is the sum of `sqrt(1+r_px^2)-1` per residual coordinate. Initial damping .001; accepted cost-decreasing steps multiply damping by .35 (floor 1e-7); rejected steps multiply by 8 (ceiling 1e12). Diagonal regularization is damping times max(diagonal,1e-8), plus 1e-9.
- Objective convergence: accepted improvement <1e-6*max(old objective,1). Step convergence: squared relative step <=9e-14, successful factorization, damping <.01, and either a prior accepted step or an already exact solution. Trial projective denominators must exceed .05. After convergence parameters freeze, but all encoded stages still execute; this is not early termination of the command buffer.
- Download final parameters/state; convert to float64 for diagnostics/geography. Nonfinite results or nonconvergence block compositing.
- Jacobian uses 32 floats per correspondence; normal/factor matrices are each (8N)^2 float32 entries. Planned scratch = observations*156 + edges*1088 + (8N)^2*8 + (8N)*12 bytes, limited to 512 MiB, excluding inputs and MPS internals. This is not constant-memory in image/edge count.

## Coherent compositor

Sources: `adm/composite.py`, `adm/coherent_composite.py`, `shaders/coherent.metal`.

- Reject homographies whose image footprint crosses the projective horizon. Fit all footprints into a canvas with longest side `max_output_dimension` (default 6500), a small margin, and north-up orientation when geographic. Output pixel spacing follows this canvas sizing, not a requested physical GSD.
- Coarse scale is min(1, 384/max(W,H), sqrt(budget/(N*8*W*H))). Round coarse dimensions, with minimum 2 per axis. `coherent_budget_mb` defaults to 32 MiB and targets observations+confidence+unary storage; rounding and other buffers mean it is not an exact total-allocation cap.
- First source pass: decode one image at a time, inverse-warp samples onto the coarse grid. Trim normalized edge distance below .02 (about 1% of image dimensions). Confidence is squared normalized edge distance. Store uchar4 observations and half confidence; form confidence-weighted mean colors.
- Unary source cost: `3*(1-sqrt(confidence)) + photometric*min(RGB_squared_distance/(3*22^2),4) + .0001*source_index`. Photometric weight is .15 only if weighted mean per-channel variance <225; otherwise zero to avoid voting displaced foreground objects away. The 22 scale is hardcoded here, not read from `selection_sigma_rgb`.
- Initialize each coarse label from minimum unary cost, then do 32 red/black relaxation sweeps. Four-neighbor Potts penalties favor matching labels, with weight `2.5/(1+neighbor_mean_RGB_squared_distance/(3*30^2))`. Preserve existing labels on ties. This is local label relaxation, not a globally optimal graph cut.
- Second source pass: compute per-source low-frequency exposure bias against the mean, excluding variance >=900. Clamp offsets to +/-32 in 8-bit channels, confidence-weight them, blur numerator/weight with MPS Gaussian sigma 6 coarse pixels, then interpolate/normalize/clamp correction at rendering time.
- Render each source footprint ROI directly from the original decoded photograph. Score = normalized edge distance +2 when that source matches the coarse label. A valid labeled source therefore wins; where unavailable, choose the best geometric confidence. Count coverage independently. Each output pixel has one source's detail plus smooth exposure adjustment; no stochastic switching or high-frequency averaging between photographs.
- Full-resolution primary buffers total 12 bytes/pixel: best float32 (4), BGRA uint8 (4), coverage uint16 (2), source ID uint16 (2). There are additional coarse buffers, decoded source/upload, filtering scratch, CPU masks, and codec allocations. At 6500x4394 the primary buffers alone are 342,732,000 bytes. No output-tile scheduler exists.
- Source IDs are zero-based; 65535 means uncovered. Footprint vectors reference original source images; index lookup returns image support with tile ID -1, not the legacy raw tile API.
- A flat homography cannot correct general 3D parallax. Coherent labels can still cut elevated objects. Seed controls other pipeline operations but this compositor does not sample random source labels.

## Runtime and optional stages

- `adm/metal.py` builds an Objective-C dylib using xcrun clang, keyed by bridge-source hash. The bridge compiles concatenated pipeline/alignment/coherent/lasso MSL at runtime in safe math mode. Shared Metal buffers expose NumPy views whose owner retains the allocation; CPU reads require synchronization. Backend is thread-local and restricted to its creating thread.
- MPS product cache clears at 64 shapes; filtering scratch cache at 4 shapes. Gaussian convolution uses reflected halos and three private RGBA32F textures per cached shape, at most (2048+2r)x(256+2r). Every exported bridge function has an autorelease pool.
- Python Buffer allocation checks live device allocation against 60% physical RAM, overridable with `ADM_METAL_MEMORY_LIMIT_MB`. Direct C solver scratch and private MPS textures are not individually guarded by that Python check; the solver has its separate planned-scratch limit. Device max-buffer size and end-of-run allocated bytes are not peak memory measurements.
- Optional lasso (`adm/lasso.py`, `shaders/lasso.metal`) builds an opaque/nonblack coarse mask, opens the footprint, casts 512 inward boundary rays, reduces to 64 polygon anchors, and refines eight times. Default inset 1%; reject missing central support or removal of >half covered pixels. Retained colors and canvas/world transform stay unchanged; removed coverage/IDs clear. It does not repair internal registration.
- Diagnostic compact flat lighting uses a fused sRGB decode/warm treatment/encode kernel and omits HDR/float lighting exports. Supplied height fields enable the other terrain-lighting path. Optional shadows use contrast-derived relief and three short screen-space rays; they are artistic, separate from neutral mapping, and do not reconstruct geometry.

## Export/cache discrepancies: preserve these distinctions

- CLI defaults to `--export-profile vectors`, while `Config()` defaults to `diagnostic`. Programmatic `run()` calls without an export_profile argument can therefore behave differently from CLI runs.
- Despite CLI help, **current `compose()` always computes the raster and writes `map_neutral.png`, `coverage.png`, `source_ids.png`, transforms, and geometry under all profiles**. `vectors` is not yet a vector-only execution path; `png` is not yet a single-raster export path.
- `adm/project.py::write_recipe()` exists but has no pipeline call site. Current runs do not write `project.json`, despite the lighting summary referring to a saved render recipe.
- Profiles vectors/png skip the entire lighting stage, including requested `--stylized-shadows`. Historical SIYI/Archive optimized runs predate this default and include golden/shadow PNGs. Their old benchmark command now has different behavior unless diagnostic is explicit.
- Explicit CLI profiles activate output quotas: 32 MiB default for vectors, 256 MiB otherwise; `--max-output-mb` overrides. Managed exports use guarded atomic writes, conservative raw-size PNG preflight, and a 512 MiB free-disk reserve. Current raster exports can defeat the nominal vector budget. Existing files count toward the cap.
- Compact mode omits raw `tiles/`, SQLite tiles, `warps/`, and full linear lighting exports, **but still saves `registration.npz` even without --resume**, plus metadata/transforms/support images. Diagnostic mode also saves corner vocabulary caches. No automatic cleanup of previous outputs is performed.
- Resume only reuses accepted match edges when the fingerprint agrees; alignment and rendering rerun. Fingerprint includes selection/input hashes, metadata, configuration, GPS mode, OpenCV, and backend fingerprint. Backend fingerprint hashes MSL files plus `metal.py` and OpenCV; contrary to older wording it does not directly hash `ADMMetal.m` or all registration/pipeline code. Dylib build hashing is separate.

## Saved measurements and storage (inspected, not newly benchmarked)

| Run | Images | Full process wall | Alignment + geography | Match edges / observations |
|---|---:|---:|---:|---:|
| SIYI optimized | 29 | 30.000 s | .459 s | 187 / 26,555 |
| Archive optimized | 63 | 33.635 s | 2.800 s | 1,551 / 241,429 |
| killerofmaps optimized, 32 MiB coarse | 306 | 121.529 s | 35.337 s | 11,254 / 1,747,493 |
| killerofmaps optimized_128mb | 306 | 119.488 s | 35.222 s | 11,254 / 1,747,493 |

Latest completed variant is `output/killerofmaps/metal_optimized_128mb` (Sept 14 00:42 local). AGL 60 m, registration width 640, skip-first 0, canvas 6500x4394, coarse grid 285x193 versus 142x96 at 32 MiB. Both large runs use vectors and explicitly raised output cap to 2048 MiB; both save neutral/support rasters but no golden/shadow output. Baseline 306-image residual median/p95 .22791/.68777 registration pixels; planned solver scratch 332,824,268 bytes. Its matching takes 67.889 s and reports 9 executed / 60 encoded iterations.

Measured logical file sizes below are MiB, exclude input photographs, and do not deduplicate hard links across separate output directories:

| Run | Match cache | Vocabulary cache | Maps/previews | Support rasters | Metadata/transforms | Total |
|---|---:|---:|---:|---:|---:|---:|
| SIYI optimized | .39 | 2.48 | 193.27 | .62 | .31 | 197.07 |
| Archive optimized | 3.28 | 4.37 | 142.31 | .92 | 1.78 | 152.68 |
| killerofmaps optimized | 23.92 | 0 | 52.35 | 1.62 | 2.29 | 80.18 |
| killerofmaps optimized_128mb | 23.92 | 0 | 52.35 | 1.64 | 2.29 | 80.20 |

The 306-image `registration.npz` is 25,077,282 bytes. Coarse budget 128 MiB is runtime working storage, not a 128 MiB saved cache file. Earlier legacy SIYI output was 1,422.04 decimal MB before cleanup. A saved cleanup manifest records 4,130,376,735 bytes removed across regenerable intermediates/trial outputs; those are historical, not currently present cache bytes.

## Exact ODM comparison

- Saved baseline is ODM 3.6.2 in ARM64 Docker, 12 visible CPUs and 7.75 GiB guest RAM. Commands are `python3 /code/run.py --project-path /datasets <dataset> --orthophoto-png --optimize-disk-space`. Reconstruction quality remains default: DSPSIFT/high, 10,000 minimum feature target, FLANN, incremental SfM, camera-parameter optimization, medium point-cloud quality, default 5 cm requested orthophoto resolution. Densification logs explicitly use `--cuda-device -2` (CPU). ADM runs natively with six OpenCV workers and Metal/MPS.
- ODM stages (`ODM/stages/odm_app.py`): dataset -> split/merge -> OpenSfM features/matching/tracks -> 3D reconstruction/bundle adjustment and undistortion -> OpenMVS dense depth/fusion -> point filtering -> 3D and 2.5D meshing -> texturing -> georeferencing -> optional DEM products -> orthophoto -> reports.
- Saved options have skip_3dmodel=false and use_3dmesh=false: ODM builds/textures both 3D and 2.5D meshes; the orthophoto uses the 2.5D mesh. DSM/DTM exports are false; do not claim those raster products were enabled merely because internal surface reconstruction occurs.
- ODM estimates 3D camera/scene geometry and camera parameters; ADM aligns 2D homographies then fits a geographic similarity. ADM has no lens-distortion calibration/undistortion stage. ODM texture selection/seam leveling operates on reconstructed surfaces; ADM selects coarse connected photo regions in the flat map and applies bounded exposure bias.
- Saved feature-processing widths: ODM 1920 SIYI /640 Archive; ADM 1400/640. ODM output rasters: 877x678 at ~5 cm/pixel (SIYI), 1621x1384 at ~21.64 cm/pixel (Archive, GSD-limited). ADM: 6500x5458 at .7947 cm/pixel; 6500x5689 at 5.6664 cm/pixel. Finer raster sampling does not establish more resolved detail or accuracy.
- ODM wall times: 279.824 s SIYI and 352.776 s Archive; ratios to saved optimized ADM are 9.33x and 10.49x. They compare different workloads and environments. From consecutive ODM log stage starts, dense MVS + meshing + texturing take about 207.52 s SIYI and 303.04 s Archive; ADM has no corresponding stages. ADM's own legacy->optimized SIYI alignment improves 49.921 s to .459 s; that comparison isolates its alignment revision better than ODM totals.
- Actual retained ODM outputs with optimize-disk-space enabled, excluding input image folders: 144.94 MiB SIYI, 145.15 MiB Archive. Corresponding ADM optimized directories are 197.07 and 152.68 MiB. Do not claim ADM always saves less disk: these ADM outputs are larger and include three large PNGs at different sampling resolutions. Persistent match caches, diagnostic output, runtime memory, and total retained disk are different measures.
- Archive held-out nominal-center RMSE: ADM 2.987 m, ODM 2.982 m. These are supplied synthetic/crop centers, not surveyed checkpoints. SIYI GPS participates in fitting. Homography correspondence residuals and ODM 3D reprojection residuals have different definitions and are not directly rankable as accuracy.
- Neutral-map comparison resamples onto a common geographic grid/physical resolution. SIYI optimized SSIM against ODM .07410, Archive .60021. Agreement with ODM is not ground truth. The optimized compositor improves the saved goal-detail example versus legacy ADM while SIYI geographic SSIM falls from .10432; no blanket quality win.
- No corresponding saved ODM timing was located for the 306-image killerofmaps run. Do not extrapolate a measured ODM speedup for it. ODM's `--fast-orthophoto` exists but was not the measured baseline; it skips dense MVS and forces skip-3dmodel while retaining SfM and surface mapping.

## Evidence and validation

Quality attribution reviewed against saved tests/comparisons:

- No stage-by-stage percentage attribution exists. GPU numerical parity tests, synthetic failure cases, and multi-change real-run comparisons answer different questions. Do not present runtime shares or source-boundary counts as percentages of map quality.
- Latest 306-image 128 MiB run: preparation 14.462 s (12.16%), matching 67.104 s (56.43%), alignment/geographic fit 35.222 s (29.62%), composition/index/export 2.136 s (1.80%), lighting skipped. Shares use the 118.924 s internal timer; external process time is 119.488 s. Existing timers do not isolate SIFT, descriptor matching, RANSAC, cache writing, GPS fitting, or individual compositor stages.
- GPS-only versus optimized Archive comparisons: geographic ODM-agreement SSIM .28493 -> .60021; MAE 46.959 ->13.215 on a common physical grid. This compares multiple changed stages, not an isolated matching ablation; it is also agreement with ODM rather than independent accuracy.
- SIYI source-transition fraction drops .17888065 -> .00232177 (17.888% -> .232%, a 98.70% reduction). This quantifies label coherence, not overall image-quality improvement. Geographic SSIM against ODM simultaneously drops .10432 -> .07410 versus legacy visually aligned ADM.
- Synthetic displaced-object test asserts output interior equals one original photograph, preserving one object without duplicated/erased copies. Exposure test uses source values 80/120 and requires neighboring output jumps <8 levels in the tested interior. These validate specific cases, not a real-dataset average benefit.
- Corner delta threshold .02 -> .10 experiment: 226 evaluated patches, 0 ->119 passing delta alone, 0 ->2 passing all gates, zero pairs with four corners. All 190 edges/homographies/correspondence sets remain identical; no map-quality improvement demonstrated (`output/101SIYI_IMG_corner10/RESULTS.md`). This experiment predates the 187-edge optimized SIYI comparison.
- Lasso synthetic tests preserve surviving pixels exactly, remove protruding/black borders, retain >80% of covered pixels in the test fixture, preserve an interior dark region and canvas, and reject unsupported central geometry. It is off in the latest measured run.
- 32 ->128 MiB coarse budget changes 306-image grid 142x96 ->285x193; saved alignment residuals are identical. No independent compositor-quality comparison for this budget change was located. Larger budget does not have a measured quality percentage.
- Existing legacy Metal test confirms recomputed warps versus disk-cache mode are pixel-identical; optimized resume test confirms unchanged neutral output and unchanged match-cache timestamp. Cache persistence is for reuse, not additional map information.

- Implementation sources above; saved results: `output/comparison/{siyi,archive}/metal_optimized/`, sibling timing/comparison JSONs, `output/killerofmaps/metal_optimized*/`, and `output/comparison/{siyi,archive}/odm/{options.json,log.json,opensfm/config.yaml,timing.json}`.
- Historical `output/metal_validation.json` reports 38 tests, zero failures/errors, lighting max absolute error 1.19209e-7. Timestamp Sept 14 00:34 precedes the final configurable-budget edit at 00:40. This review read the tests/reports; it did not rerun the GPU suite or full benchmarks.
- Review ran a tiny temporary-file probe: parsed actual CLI default as vectors and invoked the common compositor export path to confirm neutral/coverage/source-ID PNGs are written and no project.json appears. Temporary probe data were removed automatically. No implementation changes or cache deletion were performed.
