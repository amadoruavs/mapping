"""Tiled FSR1 EASU/RCAS export. CPU reference with optional HIP acceleration."""
import argparse
import ctypes as C
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import numpy as np
import rasterio
from rasterio.enums import ColorInterp
from rasterio.windows import Window
from affine import Affine
# Support both the app wrapper and direct validation/CLI execution.
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from parallel_runtime import bounded_map, worker_count
ROOT=Path(__file__).resolve().parent

class Kernel:
    def __init__(self, backend='auto', threads=4):
        self.threads=max(1,min(32,threads));self.backend='cpu'
        if backend != 'cpu' and (ROOT/'libfsr_hip.so').exists():
            try:
                self.lib=C.CDLL(str(ROOT/'libfsr_hip.so'))
                self.lib.mr_hip_fsr.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_void_p,C.c_float]
                self.lib.mr_hip_error.restype=C.c_char_p
                test=np.random.default_rng(365).integers(0,256,(31,37,4),dtype=np.uint8);test[:,:,3]=255
                test[:3,:5,3]=0
                out=np.empty((62,74,4),np.uint8)
                if self.lib.mr_hip_fsr(test.ctypes.data,37,31,out.ctypes.data,.25):
                    raise RuntimeError(self.lib.mr_hip_error().decode())
                reference=Kernel('cpu',self.threads).run(test,.25)
                if not np.array_equal(out,reference):
                    raise RuntimeError('HIP output failed CPU parity check')
                self.backend='hip';return
            except (OSError,RuntimeError) as exc:
                if backend=='hip':raise
                print('[FSR] HIP unavailable: '+str(exc),flush=True)
        elif backend=='hip':
            raise RuntimeError('HIP library missing; run build-hip.sh first')
        lib=ROOT/('libfsr_cpu.dylib' if os.uname().sysname=='Darwin' else 'libfsr_cpu.so')
        if not lib.exists() or lib.stat().st_mtime < (ROOT/'native.cpp').stat().st_mtime:
            compiler=shutil.which('c++') or shutil.which('g++')
            if not compiler:raise RuntimeError('Install a C++17 compiler')
            tmp=lib.with_name(lib.name+'.tmp')
            subprocess.run([compiler,'-std=c++17','-O3','-fno-math-errno','-fopenmp-simd','-ffp-contract=off','-pthread','-shared','-fPIC',str(ROOT/'native.cpp'),'-o',str(tmp)],check=True)
            tmp.replace(lib)
        self.lib=C.CDLL(str(lib))
        self.lib.mr_fsr_rows.argtypes=[C.c_void_p,C.c_int,C.c_int,C.c_void_p,C.c_int,C.c_int,C.c_int,C.c_float,C.c_int]
        self.lib.mr_error.restype=C.c_char_p
    def run(self, image, sharp=.25):
        image=np.ascontiguousarray(image);h,w=image.shape[:2]
        out=np.empty((h*2,w*2,4),np.uint8)
        if self.backend=='hip':
            if self.lib.mr_hip_fsr(image.ctypes.data,w,h,out.ctypes.data,sharp):
                raise RuntimeError(self.lib.mr_hip_error().decode())
        else:
            temp=np.empty_like(out)
            for src,dst,step in ((image,temp,0),(temp,out,1)):
                sh,sw=src.shape[:2]
                if self.lib.mr_fsr_rows(src.ctypes.data,sw,sh,dst.ctypes.data,0,h*2,step,sharp,self.threads):
                    raise RuntimeError(self.lib.mr_error().decode())
        return out

def finish(source, target, backend='auto', threads=4, sharp=.25, tile=512):
    if not 0<=sharp<=1 or not np.isfinite(sharp):raise ValueError('Sharpness must be 0..1')
    if not 32<=tile<=2048:raise ValueError('Tile must be 32..2048')
    source=Path(source);target=Path(target)
    if source.resolve()==target.resolve():raise ValueError('Use a separate output file')
    kernel=Kernel(backend,threads);start=time.perf_counter()
    temporary=target.with_name(target.name+'.partial.tif')
    try:
        with rasterio.Env(GDAL_CACHEMAX=256*1024*1024), rasterio.open(source) as src:
            if src.count<3 or any(d!='uint8' for d in src.dtypes[:3]):
                raise ValueError('FSR display export requires an RGB uint8 orthophoto; original remains untouched')
            profile=src.profile.copy()
            profile.update(width=src.width*2,height=src.height*2,count=4,dtype='uint8',
                transform=src.transform*Affine.scale(.5,.5),nodata=None,driver='GTiff',
                compress='deflate',predictor=2,tiled=True,blockxsize=256,blockysize=256,BIGTIFF='IF_SAFER')
            with rasterio.open(temporary,'w',**profile) as dst:
                dst.colorinterp=(ColorInterp.red,ColorInterp.green,ColorInterp.blue,ColorInterp.alpha)
                workers=worker_count(min(4,threads)) if kernel.backend=='cpu' else 1
                kernel.threads=max(1,threads//workers)
                def tiles():
                    # GDAL reads happen only on this producer thread.
                    for y in range(0,src.height,tile):
                        for x in range(0,src.width,tile):
                            tw=min(tile,src.width-x);th=min(tile,src.height-y)
                            lx=max(0,x-4);ly=max(0,y-4);rx=min(src.width,x+tw+4);by=min(src.height,y+th+4)
                            win=Window(lx,ly,rx-lx,by-ly)
                            rgb=src.read([1,2,3],window=win).transpose(1,2,0)
                            alpha=src.dataset_mask(window=win)
                            if ColorInterp.alpha in src.colorinterp:
                                alpha=np.minimum(alpha,src.read(src.colorinterp.index(ColorInterp.alpha)+1,window=win))
                            yield np.dstack((rgb[:,:,::-1],alpha)),(x,y,tw,th,lx,ly)
                def process_tile(item):
                    image,(x,y,tw,th,lx,ly)=item
                    out=kernel.run(image,sharp)
                    crop=out[2*(y-ly):2*(y-ly+th),2*(x-lx):2*(x-lx+tw)]
                    return crop[:,:,[2,1,0,3]].transpose(2,0,1),(x,y,tw,th)
                for data,(x,y,tw,th) in bounded_map(process_tile,tiles(),workers=workers,bytes_per_item=(tile+8)**2*128):
                    # Output writes are deterministic and never concurrent on GDAL.
                    dst.write(data,window=Window(x*2,y*2,tw*2,th*2))
                    if x+tw==src.width:print(f'[FSR {kernel.backend}] {min(y+tile,src.height)*100//src.height}%',flush=True)
                dst.update_tags(FSR='FSR1 FP32 EASU + RCAS',FSR_BACKEND=kernel.backend,
                                FSR_SHARPNESS=str(sharp),DETAIL_NOTE='Spatial display upscaling; no new measured ground detail')
        temporary.replace(target)
    finally:
        if temporary.exists():temporary.unlink()
    report=dict(backend=kernel.backend,seconds=time.perf_counter()-start,sharpness=sharp,tile=tile,output=str(target))
    target.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('target')
    p.add_argument('--backend',choices=['auto','cpu','hip'],default='auto');p.add_argument('--threads',type=int,default=4)
    p.add_argument('--sharpness',type=float,default=.25)
    a=p.parse_args();print(finish(a.source,a.target,a.backend,a.threads,a.sharpness))
