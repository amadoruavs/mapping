#!/usr/bin/env bash
set -euo pipefail
fsr_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
fsr_hipcc="${HIPCC:-$(command -v hipcc || true)}"
if [[ -z "$fsr_hipcc" && -x /opt/rocm/bin/hipcc ]]; then fsr_hipcc=/opt/rocm/bin/hipcc; fi
if [[ -z "$fsr_hipcc" ]]; then echo 'HIP compiler unavailable. Install Fedora rocm-hip-devel, then rerun this script.' >&2; exit 1; fi
"$fsr_hipcc" -x hip -std=c++17 -O3 -ffp-contract=off --offload-arch=gfx1150 -fPIC -shared \
  "$fsr_root/fsr_hip.cpp" -o "$fsr_root/libfsr_hip.so.tmp"
mv "$fsr_root/libfsr_hip.so.tmp" "$fsr_root/libfsr_hip.so"
echo 'Built HIP FSR for Ryzen AI 9 365 / gfx1150. Run validate.py --hip on the target before relying on GPU output.'
