#include <hip/hip_runtime.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include "fsr_device.h"
static thread_local char error_text[512];
extern "C" const char* mr_hip_error(){return error_text;}
__global__ void fsr_pass(const uint8_t*src,int w,int h,uint8_t*dst,int pass,float sharp){
    const int x=blockIdx.x*blockDim.x+threadIdx.x,y=blockIdx.y*blockDim.y+threadIdx.y;
    const int ow=pass?w:w*2,oh=pass?h:h*2;
    if(x<ow&&y<oh)store(dst+(size_t(y)*ow+x)*4,pass?rcas(src,w,h,x,y,sharp):easu(src,w,h,x,y));
}
extern "C" int mr_hip_fsr(const uint8_t*src,int w,int h,uint8_t*dst,float sharp){
    uint8_t *input=nullptr,*temp=nullptr,*output=nullptr;
    hipError_t err=hipSuccess;
    if(!src||!dst||w<1||h<1||w>4096||h>4096||!std::isfinite(sharp)||sharp<0||sharp>1){
        std::snprintf(error_text,sizeof(error_text),"Invalid HIP FSR input");return -1;
    }
    const size_t bytes=size_t(w)*h*4;
#define CHECK(call) do {err=(call);if(err!=hipSuccess)goto cleanup;}while(0)
    CHECK(hipMalloc(&input,bytes));CHECK(hipMalloc(&temp,bytes*4));CHECK(hipMalloc(&output,bytes*4));
    CHECK(hipMemcpy(input,src,bytes,hipMemcpyHostToDevice));
    hipLaunchKernelGGL(fsr_pass,dim3((w*2+15)/16,(h*2+15)/16),dim3(16,16),0,0,input,w,h,temp,0,sharp);
    CHECK(hipGetLastError());
    hipLaunchKernelGGL(fsr_pass,dim3((w*2+15)/16,(h*2+15)/16),dim3(16,16),0,0,temp,w*2,h*2,output,1,sharp);
    CHECK(hipGetLastError());CHECK(hipMemcpy(dst,output,bytes*4,hipMemcpyDeviceToHost));
cleanup:
    if(input)hipFree(input);if(temp)hipFree(temp);if(output)hipFree(output);
    if(err!=hipSuccess){std::snprintf(error_text,sizeof(error_text),"%s",hipGetErrorString(err));return -1;}
    return 0;
}
