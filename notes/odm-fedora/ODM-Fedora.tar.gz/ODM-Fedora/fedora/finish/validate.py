"""Local CPU validation; --hip requires and compares the real AMD backend."""
import argparse
import json
from pathlib import Path
import tempfile
import time
import numpy as np
import rasterio
from rasterio.enums import ColorInterp
from rasterio.transform import from_origin
from fsr import Kernel,finish

def main():
    p=argparse.ArgumentParser();p.add_argument('--hip',action='store_true');p.add_argument('--image',type=Path)
    p.add_argument('--output',type=Path,default=Path('fsr-validation.json'));a=p.parse_args()
    rng=np.random.default_rng(9);image=rng.integers(0,256,(113,157,4),dtype=np.uint8)
    image[:,:,3]=255;image[:9,:12,3]=0
    kernel=Kernel('cpu',4);full=kernel.run(image)
    np.testing.assert_array_equal(full[:,:,3],image[:,:,3].repeat(2,0).repeat(2,1))
    report={'alpha_exact':True,'hip_tested':False}
    with tempfile.TemporaryDirectory() as name:
        root=Path(name);src=root/'source.tif';dst=root/'out.tif'
        with rasterio.open(src,'w',driver='GTiff',width=157,height=113,count=4,dtype='uint8',crs='EPSG:32615',transform=from_origin(500000,4000000,.05,.05)) as ds:
            ds.write(image[:,:,[2,1,0,3]].transpose(2,0,1));ds.colorinterp=(ColorInterp.red,ColorInterp.green,ColorInterp.blue,ColorInterp.alpha)
        finish(src,dst,'cpu',4,tile=32)
        with rasterio.open(src) as s,rasterio.open(dst) as d:
            np.testing.assert_array_equal(d.read().transpose(1,2,0),full[:,:,[2,1,0,3]])
            assert s.bounds==d.bounds and s.crs==d.crs
        report.update(tile_seams_exact=True,georeference_exact=True)
    if a.image:
        from PIL import Image
        real=np.array(Image.open(a.image).convert('RGBA'))[:1024,:1024]
        real=real[:,:,[2,1,0,3]].copy()
        kernel.run(real) # warm compiler/cache separately
        timings=[]
        for _ in range(3):
            start=time.perf_counter();out=kernel.run(real);timings.append(time.perf_counter()-start)
        a.output.parent.mkdir(parents=True,exist_ok=True)
        Image.fromarray(out[:,:,[2,1,0,3]]).save(a.output.with_suffix('.png'))
        report.update(real_image=str(a.image),input_shape=list(real.shape),cpu_seconds=timings)
    if a.hip:
        gpu=Kernel('hip',4);accelerated=gpu.run(image)
        delta=np.abs(accelerated.astype(np.int16)-full.astype(np.int16))
        assert delta.max()==0,delta.max()
        np.testing.assert_array_equal(accelerated[:,:,3],full[:,:,3])
        report.update(hip_tested=True,hip_max_code_difference=int(delta.max()))
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
