// FSR1 FP32 equations from native.cpp; AMD MIT license in FSR_LICENSE.txt.
struct V {float x,y,z; __device__ float& operator[](int i){return i==0?x:i==1?y:z;} __device__ float operator[](int i)const{return i==0?x:i==1?y:z;}};
__device__ V operator+(V a,V b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
__device__ V operator-(V a,V b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
__device__ V operator*(V a,float b){return {a.x*b,a.y*b,a.z*b};}
__device__ V operator*(V a,V b){return {a.x*b.x,a.y*b.y,a.z*b.z};}
__device__ V operator/(V a,float b){return a*(1.f/b);}
__device__ float dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
__device__ V cross(V a,V b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
__device__ V norm(V a){return a/std::sqrt(std::max(dot(a,a),1e-30f));}
__device__ V lo(V a,V b){return {std::min(a.x,b.x),std::min(a.y,b.y),std::min(a.z,b.z)};}
__device__ V hi(V a,V b){return {std::max(a.x,b.x),std::max(a.y,b.y),std::max(a.z,b.z)};}
__device__ V clamp(V a,V l,V h){return lo(hi(a,l),h);}
__device__ float sat(float x){return std::clamp(x,0.f,1.f);}
__device__ float lum(V c){return .5f*c.x+c.y+.5f*c.z;}
struct P {V c;float a;};
__device__ P load(const uint8_t*s,int x,int y,int w,int h){
    x=std::clamp(x,0,w-1);y=std::clamp(y,0,h-1);const auto*p=s+(size_t(y)*w+x)*4;
    return {{p[0]/255.f,p[1]/255.f,p[2]/255.f},p[3]/255.f};
}
__device__ void store(uint8_t*d,P p){for(int c=0;c<3;c++)d[c]=uint8_t(std::nearbyint(sat(p.c[c])*255.f));d[3]=uint8_t(std::nearbyint(sat(p.a)*255.f));}
__device__ P easu(const uint8_t*s,int w,int h,int x,int y){
    float xx=(x+.5f)*.5f-.5f,yy=(y+.5f)*.5f-.5f;int bx=int(std::floor(xx)),by=int(std::floor(yy));
    float px=xx-bx,py=yy-by;
    constexpr int ox[12]={0,1,-1,0,0,-1,1,2,2,1,1,0},oy[12]={-1,-1,1,1,0,0,1,1,0,0,2,2};
    P t[12];float l[12],alpha=1;
    for(int k=0;k<12;k++){t[k]=load(s,bx+ox[k],by+oy[k],w,h);l[k]=lum(t[k].c);alpha=std::min(alpha,t[k].a);}
    if(alpha<1){
        float weight[4]={(1-px)*(1-py),px*(1-py),(1-px)*py,px*py};int ix[4]={4,9,3,6};
        V c{};float sum=0;for(int k=0;k<4;k++){float q=weight[k]*t[ix[k]].a;c=c+t[ix[k]].c*q;sum+=q;}
        float a=load(s,int(std::floor(xx+.5f)),int(std::floor(yy+.5f)),w,h).a;
        return {a>0?c/std::max(sum,1e-8f):V{},a};
    }
    float dx=0,dy=0,len=0;
    auto set=[&](float weight,float a,float b,float c,float d,float e){
        float gx=d-b,gy=e-a,mx=std::max(std::abs(d-c),std::abs(c-b)),my=std::max(std::abs(e-c),std::abs(c-a));
        float ex=sat(std::abs(gx)/std::max(mx,1e-8f)),ey=sat(std::abs(gy)/std::max(my,1e-8f));
        dx+=gx*weight;dy+=gy*weight;len+=(ex*ex+ey*ey)*weight;
    };
    set((1-px)*(1-py),l[0],l[5],l[4],l[9],l[3]);set(px*(1-py),l[1],l[4],l[9],l[8],l[6]);
    set((1-px)*py,l[4],l[2],l[3],l[6],l[11]);set(px*py,l[9],l[3],l[6],l[7],l[10]);
    float d2=dx*dx+dy*dy;if(d2<1.f/32768.f){dx=1;dy=0;}else{float d=std::sqrt(d2);dx/=d;dy/=d;}
    len*=.5f;len*=len;float stretch=(dx*dx+dy*dy)/std::max(std::abs(dx),std::abs(dy));
    float lx=1+(stretch-1)*len,ly=1-.5f*len,lobe=.5f+(.21f-.5f)*len,clip=1/lobe,total=0;V color{};
    for(int k=0;k<12;k++){
        float ax=ox[k]-px,ay=oy[k]-py,vx=(ax*dx+ay*dy)*lx,vy=(-ax*dy+ay*dx)*ly;
        float d=std::min(vx*vx+vy*vy,clip),wb=.4f*d-1,wa=lobe*d-1;
        wb=1.5625f*wb*wb-.5625f;float weight=wb*wa*wa;color=color+t[k].c*weight;total+=weight;
    }
    return {clamp(color/total,lo(lo(t[4].c,t[9].c),lo(t[3].c,t[6].c)),hi(hi(t[4].c,t[9].c),hi(t[3].c,t[6].c))),1};
}
__device__ P rcas(const uint8_t*s,int w,int h,int x,int y,float strength){
    P b=load(s,x,y-1,w,h),d=load(s,x-1,y,w,h),e=load(s,x,y,w,h),f=load(s,x+1,y,w,h),v=load(s,x,y+1,w,h);
    if(std::min(std::min(b.a,d.a),std::min(e.a,std::min(f.a,v.a)))<1)return e;
    float bl=lum(b.c),dl=lum(d.c),el=lum(e.c),fl=lum(f.c),vl=lum(v.c);
    float range=std::max(std::max(bl,dl),std::max(el,std::max(fl,vl)))-std::min(std::min(bl,dl),std::min(el,std::min(fl,vl)));
    float noise=1-.5f*sat(std::abs(.25f*(bl+dl+fl+vl)-el)/std::max(range,1e-8f));
    V mn=lo(lo(b.c,d.c),lo(f.c,v.c)),mx=hi(hi(b.c,d.c),hi(f.c,v.c));float lobe=-1;
    for(int c=0;c<3;c++){
        float hitMin=std::min(mn[c],e.c[c])/std::max(4*mx[c],1e-8f);
        float hitMax=(1-std::max(mx[c],e.c[c]))/std::min(4*mn[c]-4,-1e-8f);
        lobe=std::max(lobe,std::max(-hitMin,hitMax));
    }
    lobe=std::clamp(lobe,-.1875f,0.f)*strength*noise;
    return {((b.c+d.c+v.c+f.c)*lobe+e.c)/(4*lobe+1),e.a};
}
