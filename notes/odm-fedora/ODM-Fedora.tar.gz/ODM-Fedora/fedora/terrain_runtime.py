"""CPU work reuse for Ultra orthophotos; no reconstruction math/settings change."""
from collections import OrderedDict
from concurrent.futures import Future
from threading import Lock
import os

from parallel_runtime.scheduler import memory_budget, MIB


class ArrayCache:
    """Byte-bounded LRU with one producer per key, including concurrent misses.

    Callers may retain returned arrays; this bounds cache ownership, not all
    native allocations. Values larger than the budget are never retained.
    """
    def __init__(self, budget, size):
        self.budget = max(0, int(budget))
        self.size = size
        self.values = OrderedDict()
        self.pending = {}
        self.lock = Lock()
        self.bytes = 0
        self.peak_bytes = 0
        self.hits = self.misses = self.waits = 0

    def get(self, key, load):
        with self.lock:
            if key in self.values:
                value, size = self.values.pop(key)
                self.values[key] = value, size
                self.hits += 1
                return value
            producer = key not in self.pending
            if producer:
                future = self.pending[key] = Future()
                self.misses += 1
            else:
                future = self.pending[key]
                self.waits += 1
        if not producer:
            return future.result()
        try:
            value = load()
            size = self.size(value)
            with self.lock:
                if 0 < size <= self.budget:
                    while self.values and self.bytes + size > self.budget:
                        _, (_, removed) = self.values.popitem(last=False)
                        self.bytes -= removed
                    self.values[key] = value, size
                    self.bytes += size
                    self.peak_bytes = max(self.peak_bytes, self.bytes)
            future.set_result(value)
            return value
        except BaseException as error:
            future.set_exception(error)
            raise
        finally:
            with self.lock:
                self.pending.pop(key, None)

    def report(self):
        return dict(hits=self.hits, misses=self.misses, waits=self.waits,
                    bytes=self.bytes, peak_bytes=self.peak_bytes, budget=self.budget)


def feature_bytes(value):
    if value is None:
        return 0
    arrays = [value.points, value.descriptors, value.colors]
    if value.semantic is not None:
        arrays += [value.semantic.segmentation, value.semantic.instances]
    # Small metadata allowance; descriptor/point/color array storage dominates.
    return 4096 + sum(getattr(a, 'nbytes', 0) for a in arrays)


def install_feature_cache():
    """Cache decoded features, leaving FLANN/RANSAC and pair order untouched."""
    from opensfm import feature_loader
    loader = feature_loader.instance
    original = loader._load_features_nocache
    ceiling = int(os.environ.get('ODM_FEATURE_CACHE_MB', '4096')) * MIB
    if ceiling < 0:
        raise ValueError('ODM_FEATURE_CACHE_MB must be non-negative')
    cache = ArrayCache(min(ceiling, memory_budget() // 4), feature_bytes)
    loader._load_features_nocache = lambda data, image: cache.get(
        (data, image), lambda: original(data, image))
    return cache


def install_camera_mapping_cache():
    """Avoid every initial undistortion worker building the same camera map."""
    from opensfm import undistort
    original = undistort.compute_camera_mapping_cached
    if getattr(original, '_ultra_single_producer', False):
        return
    # Camera maps already live in upstream's per-run cache. Synchronize creation
    # without a second owning cache, and retain upstream export/clear semantics.
    lock = Lock()

    def mapping(camera, new_camera, width, height):
        key = '%s-%s-%s-%s' % (camera.id, new_camera.id, width, height)
        cached = undistort._camera_mapping_cache.get(key)
        if cached is not None:
            return cached['map']
        with lock:
            return original(camera, new_camera, width, height)

    mapping._ultra_single_producer = True
    undistort.compute_camera_mapping_cached = mapping


def enabled():
    return os.environ.get('ODM_TERRAIN_RUNTIME', '1') != '0'
