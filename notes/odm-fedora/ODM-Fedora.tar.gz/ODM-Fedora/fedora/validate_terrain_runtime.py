"""Real-photo decoded-feature and camera-map parity; no speed/accuracy extrapolation."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT/'SuperBuild/install/bin/opensfm')]


def worker(project, output, optimized):
    import cv2
    import numpy as np
    from opensfm import dataset, feature_loader, matching, undistort
    from terrain_runtime import install_feature_cache, install_camera_mapping_cache
    data = dataset.DataSet(str(project))
    names = sorted(data.images())
    cache = install_feature_cache() if optimized else None
    loader = feature_loader.instance
    digest = hashlib.sha256()
    start = time.perf_counter()
    # Round-robin repeated access crosses upstream's 20-image raw-cache capacity.
    # This is a decode-cache benchmark, not end-to-end matching throughput.
    for _ in range(3):
        for name in names:
            value = loader._load_all_data_unmasked(data, name)
            for array in (value.points, value.descriptors, value.colors):
                digest.update(array.tobytes())
    report = dict(images=len(names), decode_seconds=time.perf_counter()-start,
                  decoded_arrays_sha256=digest.hexdigest())
    if cache:
        report['cache'] = cache.report()
    # All descriptor matching decisions remain upstream. Compare a reproducible
    # selection spanning the entire set, with matching randomness controlled.
    cameras = data.load_camera_models()
    pairs = [(names[i], names[i+1]) for i in range(0, len(names)-1, max(1, len(names)//24))]
    start = time.perf_counter()
    matches = {}
    for first, second in pairs:
        cv2.setRNGSeed(42)
        a, b = data.load_exif(first), data.load_exif(second)
        result = matching.match_descriptors(first, second, cameras[a['camera']], cameras[b['camera']], data, {})
        matches[first+'|'+second] = np.asarray(result).tolist()
    report['descriptor_seconds'] = time.perf_counter()-start
    report['descriptor_matches'] = matches
    # Multiple simultaneous initial misses used to repeat this native map build.
    camera = next(iter(cameras.values()))
    if data.reconstruction_exists():
        camera = next(iter(data.load_reconstruction()[0].cameras.values()))
    convert = getattr(undistort, 'perspective_camera_from_' + camera.projection_type)
    new_camera = convert(camera)
    undistort._camera_mapping_cache = {}
    original = undistort.pygeometry.compute_camera_mapping
    calls = []
    def counted(*args):
        calls.append(1)
        return original(*args)
    undistort.pygeometry.compute_camera_mapping = counted
    if optimized:
        install_camera_mapping_cache()
    start = time.perf_counter()
    with ThreadPoolExecutor(8) as pool:
        maps = list(pool.map(lambda _: undistort.compute_camera_mapping_cached(camera, new_camera, camera.width, camera.height), range(8)))
    report['camera_mapping_seconds'] = time.perf_counter()-start
    report['camera_mapping_shape'] = list(maps[0][0].shape)
    report['camera_mapping_calls'] = len(calls)
    report['camera_mapping_sha256'] = hashlib.sha256(b''.join(a.tobytes() for a in maps[0])).hexdigest()
    report['camera_mapping_workers_equal'] = all(np.array_equal(a, b) for maps_pair in maps for a, b in zip(maps[0], maps_pair))
    output.write_text(json.dumps(report, indent=2)+'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True, help='Existing OpenSfM project with features')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', choices=['baseline', 'optimized'])
    args = parser.parse_args()
    if args.worker:
        worker(args.project.resolve(), args.output, args.worker == 'optimized')
        return
    args.output.mkdir(parents=True, exist_ok=False)
    for variant in ('baseline', 'optimized'):
        subprocess.run([sys.executable, __file__, '--project', str(args.project.resolve()),
                        '--output', str(args.output/(variant+'.json')), '--worker', variant], check=True)
    a, b = [json.loads((args.output/(v+'.json')).read_text()) for v in ('baseline', 'optimized')]
    checks = {key: a[key] == b[key] for key in ['decoded_arrays_sha256', 'descriptor_matches', 'camera_mapping_sha256']}
    checks['camera_mapping_workers_equal'] = a['camera_mapping_workers_equal'] and b['camera_mapping_workers_equal']
    checks['single_camera_map_computation'] = b['camera_mapping_calls'] == 1
    report = dict(passed=all(checks.values()), checks=checks,
                  baseline={k:v for k,v in a.items() if k!='descriptor_matches'},
                  optimized={k:v for k,v in b.items() if k!='descriptor_matches'})
    (args.output/'result.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    if not report['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
