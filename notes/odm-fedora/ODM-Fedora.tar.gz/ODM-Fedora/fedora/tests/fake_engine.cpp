#include <QtCore>
#include <cstdio>
#ifdef Q_OS_LINUX
#include <unistd.h>
#include <signal.h>
#endif
static void write(const QString& path,const QByteArray& data) {QFile f(path);if(f.open(QIODevice::WriteOnly))f.write(data);}
int main(int argc,char** argv) {
    QCoreApplication app(argc,argv);const auto args=app.arguments();
    const int i=args.indexOf("--project-path");if(i<0||i+1>=args.size()) return 2;
    const auto root=args[i+1];const auto flight=root+"/flight";QDir().mkpath(flight+"/odm_orthophoto");
    write(root+"/invocation.json",QJsonDocument(QJsonArray::fromStringList(args)).toJson());
    std::puts("Running opensfm stage");std::fflush(stdout);
    const auto mode=qgetenv("ODM_TEST_MODE");
#ifdef Q_OS_LINUX
    if(mode=="child") {
        const auto child=fork();
        if(child==0) {setsid();signal(SIGTERM,SIG_IGN);for(;;) pause();}
        if(child<0) return 3;
        write(root+"/child.pid",QByteArray::number(child));
        QTimer::singleShot(60000,&app,&QCoreApplication::quit);return app.exec();
    }
#endif
    if(mode=="wait") {QTimer::singleShot(60000,&app,&QCoreApplication::quit);return app.exec();}
    if(mode=="fail") {write(flight+"/log.json","{\"success\":false}");return 1;}
    if(mode!="missing") write(flight+"/odm_orthophoto/odm_orthophoto.tif","fixture GeoTIFF placeholder");
    if(mode!="missing") write(flight+"/odm_orthophoto/odm_orthophoto_fsr2x.tif","fixture FSR GeoTIFF placeholder");
    write(flight+"/log.json","{\"success\":true}");
    std::puts("Running odm_orthophoto stage");return 0;
}
