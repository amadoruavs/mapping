import sys
from pathlib import Path
import unittest
from concurrent.futures import ThreadPoolExecutor
from threading import Event

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from terrain_runtime import ArrayCache


class CacheTests(unittest.TestCase):
    def test_concurrent_misses_share_one_result(self):
        cache = ArrayCache(100, len)
        entered, release = Event(), Event()
        calls = []
        def load():
            calls.append(1)
            entered.set()
            self.assertTrue(release.wait(5))
            return bytearray(20)
        with ThreadPoolExecutor(8) as pool:
            futures = [pool.submit(cache.get, 'camera', load) for _ in range(8)]
            self.assertTrue(entered.wait(5))
            release.set()
            values = [future.result() for future in futures]
        self.assertEqual(len(calls), 1)
        self.assertTrue(all(value is values[0] for value in values))
        self.assertEqual(cache.bytes, 20)

    def test_eviction_and_oversized_result(self):
        cache = ArrayCache(10, len)
        one = cache.get(1, lambda: bytearray(6))
        cache.get(2, lambda: bytearray(6))
        self.assertNotIn(1, cache.values)
        cache.get(3, lambda: bytearray(11))
        self.assertNotIn(3, cache.values)
        self.assertEqual(one, bytearray(6))
        self.assertLessEqual(cache.peak_bytes, 10)

    def test_failure_allows_retry(self):
        cache = ArrayCache(10, len)
        def fail():
            raise MemoryError('injected')
        with self.assertRaises(MemoryError):
            cache.get('x', fail)
        self.assertFalse(cache.pending)
        self.assertEqual(cache.get('x', lambda: b'ok'), b'ok')


if __name__ == '__main__':
    unittest.main()
