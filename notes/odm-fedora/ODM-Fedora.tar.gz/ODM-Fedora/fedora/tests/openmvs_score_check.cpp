#include "libs/MVS/Common.h"
#include "libs/MVS/DepthMap.h"
#include <chrono>
#include <random>
#include <cstring>
#include <iostream>
using namespace MVS;
using namespace SEACAVE;
struct CheckEstimator:DepthEstimator {
using DepthEstimator::DepthEstimator;
float reference(const DepthData::ViewData& image1, Depth depth, const Normal& normal)
{
	// center a patch of given size on the segment and fetch the pixel values in the target image
	Matrix3x3f H(ComputeHomographyMatrix(image1, depth, normal));
	Point3f X;
	ProjectVertex_3x3_2_3(H.val, Point2f(float(x0.x-nSizeHalfWindow),float(x0.y-nSizeHalfWindow)).ptr(), X.ptr());
	Point3f baseX(X);
	H *= float(nSizeStep);
	int n(0);
	float sum(0);
	#if DENSE_NCC != DENSE_NCC_DEFAULT
	float sumSq(0), num(0);
	#endif
	#if DENSE_NCC == DENSE_NCC_WEIGHTED
	const Weight& w = weightMap0[x0.y*image0.image.width()+x0.x];
	#endif
	for (int i=-nSizeHalfWindow; i<=nSizeHalfWindow; i+=nSizeStep) {
		for (int j=-nSizeHalfWindow; j<=nSizeHalfWindow; j+=nSizeStep) {
			const Point2f pt(X);
			if (!image1.image.isInsideWithBorder<float,1>(pt))
				return thRobust;
			const float v(image1.image.sample(pt));
			#if DENSE_NCC == DENSE_NCC_FAST
			sum += v;
			sumSq += SQUARE(v);
			num += texels0(n++)*v;
			#elif DENSE_NCC == DENSE_NCC_WEIGHTED
			const Weight::Pixel& pw = w.weights[n++];
			const float vw(v*pw.weight);
			sum += vw;
			sumSq += v*vw;
			num += v*pw.tempWeight;
			#else
			sum += texels1(n++)=v;
			#endif
			X.x += H[0]; X.y += H[3]; X.z += H[6];
		}
		baseX.x += H[1]; baseX.y += H[4]; baseX.z += H[7];
		X = baseX;
	}
	ASSERT(n == nTexels);
	// score similarity of the reference and target texture patches
	#if DENSE_NCC == DENSE_NCC_FAST
	const float normSq1(sumSq-SQUARE(sum/nSizeWindow));
	#elif DENSE_NCC == DENSE_NCC_WEIGHTED
	const float normSq1(sumSq-SQUARE(sum)/w.sumWeights);
	#else
	const float normSq1(normSqDelta<float,float,nTexels>(texels1.data(), sum/(float)nTexels));
	#endif
	const float nrmSq(normSq0*normSq1);
	if (nrmSq <=1e-16f)
		return thRobust;
	#if DENSE_NCC == DENSE_NCC_DEFAULT
	const float num(texels0.dot(texels1));
	#endif
	const float ncc(CLAMP(num/SQRT(nrmSq), -1.f, 1.f));
	float score(1.f-ncc);
	#if DENSE_SMOOTHNESS != DENSE_SMOOTHNESS_NA
	// encourage smoothness
	for (const NeighborEstimate& neighbor: neighborsClose) {
		ASSERT(neighbor.depth > 0);
		#if DENSE_SMOOTHNESS == DENSE_SMOOTHNESS_PLANE
		const float factorDepth(DENSE_EXP(SQUARE(plane.Distance(neighbor.X)/depth) * smoothSigmaDepth));
		#else
		const float factorDepth(DENSE_EXP(SQUARE((depth-neighbor.depth)/depth) * smoothSigmaDepth));
		#endif
		const float factorNormal(DENSE_EXP(SQUARE(ACOS(ComputeAngle(normal.ptr(), neighbor.normal.ptr()))) * smoothSigmaNormal));
		score *= (1.f - smoothBonusDepth * factorDepth) * (1.f - smoothBonusNormal * factorNormal);
	}
	#endif
	if (!image1.depthMap.empty()) {
		ASSERT(OPTDENSE::fEstimationGeometricWeight > 0);
		float consistency(4.f);
		const Point3f X1(image1.Tl*Point3f(float(X0.x)*depth,float(X0.y)*depth,depth)+image1.Tm); // Kj * Rj * (Ri.t() * X + Ci - Cj)
		if (X1.z > 0) {
			const Point2f x1(X1);
			if (image1.depthMap.isInsideWithBorder<float,1>(x1)) {
				Depth depth1;
				if (image1.depthMap.sample(depth1, x1, [&X1](Depth d) { return IsDepthSimilar(X1.z, d, 0.03f); })) {
					const Point2f xb(image1.Tr*Point3f(x1.x*depth1,x1.y*depth1,depth1)+image1.Tn); // Ki * Ri * (Rj.t() * Kj-1 * X + Cj - Ci)
					const float dist(norm(Point2f(float(x0.x)-xb.x, float(x0.y)-xb.y)));
					consistency = MINF(SQRT(dist*(dist+2.f)), consistency);
				}
			}
		}
		score += OPTDENSE::fEstimationGeometricWeight * consistency;
	}
	// apply depth prior weight based on patch textureless
	if (!lowResDepthMap.empty()) {
		const Depth d0 = lowResDepthMap(x0);
		if (d0 > 0) {
			const float deltaDepth(MINF(DepthSimilarity(d0, depth), 0.5f));
			const float smoothSigmaDepth(-1.f / (1.f * 0.02f)); // 0.12: patch texture variance below 0.02 (0.12^2) is considered texture-less
			const float factorDeltaDepth(DENSE_EXP(normSq0 * smoothSigmaDepth));
			score = (1.f-factorDeltaDepth)*score + factorDeltaDepth*deltaDepth;
		}
	}
	ASSERT(ISFINITE(score));
	return MIN(2.f, score);
}

};
int main(){
 DepthData data; data.dMin=1;data.dMax=30;
 data.images.Resize(6);
 std::mt19937 rng(365);std::uniform_real_distribution<float> random(0.f,1.f);
 Matrix3x3 K(100,0,32, 0,100,32, 0,0,1),R(Matrix3x3::eye());
 for(int i=0;i<6;++i){
  auto& v=data.images[i];v.camera=Camera(K,R,Point3(.03*i,0,0));v.cameraDepthMap=v.camera;
  v.image.create(64,64);v.depthMap.create(64,64);v.depthMap.setTo(10.f);
  for(int y=0;y<64;y++)for(int x=0;x<64;x++)v.image(y,x)=random(rng);
 }
 for(auto& v:data.images)v.Init(data.images[0].camera);
 data.depthMap.create(64,64);data.depthMap.setTo(10.f);
 data.normalMap.create(64,64);data.confMap.create(64,64);
 volatile Thread::safe_t idx=-1;
 DepthEstimator::WeightMap weights(64*64);DepthEstimator::MapRefArr coords;
 CheckEstimator est(0,data,idx,weights,coords);
 est.lowResDepthMap.create(64,64);est.lowResDepthMap.setTo(10.f);
 Normal normal(0,0,-1);
 for(int k=0;k<200000;k++){
  est.PreparePixelPatch(ImageRef(5+rng()%54,5+rng()%54));est.FillPixelPatch();
  normal=Normal(random(rng)-.5f,random(rng)-.5f,-1.f);normal/=cv::norm(normal);
  const float depth=2.f+26.f*random(rng);est.InitPlane(depth,normal);
  est.neighborsClose.clear();
  for(int j=0;j<k%5;j++){DepthEstimator::NeighborEstimate n;n.depth=9+random(rng);n.normal=normal;n.X=Point3f(0,0,n.depth);est.neighborsClose.push_back(n);}
  est.candidateSmoothReady=false;est.candidatePriorReady=false;
  for(const auto& v:est.images){float ref=est.reference(v,depth,normal),out=est.ScorePixelImage(v,depth,normal);
   if(std::memcmp(&ref,&out,sizeof(float))){std::cerr<<"Mismatch "<<k<<" "<<ref<<" "<<out<<"\n";return 1;}
  }
 }
 std::cout<<"1000000 scores: bit-identical\n";
 est.PreparePixelPatch(ImageRef(32,32));est.FillPixelPatch();est.InitPlane(10.f,normal);
 volatile float checksum=0;
 for(int mode=0;mode<2;mode++){
  auto start=std::chrono::steady_clock::now();
  for(int k=0;k<2000000;k++){
   est.candidateSmoothReady=false;est.candidatePriorReady=false;
   for(const auto& v:est.images)checksum += mode?est.ScorePixelImage(v,10.f,normal):est.reference(v,10.f,normal);
  }
  std::cout<<(mode?"cached":"reference")<<" seconds "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"\n";
 }
 return checksum<0;
}
