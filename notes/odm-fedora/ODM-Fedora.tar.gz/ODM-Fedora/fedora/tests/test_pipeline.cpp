#include "pipeline.h"
#include "server.h"
#include <QTcpSocket>
#include <QtTest>
using namespace odm;
static void put(const QString& path,const QByteArray& data) {
    QDir().mkpath(QFileInfo(path).absolutePath());QFile f(path);QVERIFY(f.open(QIODevice::WriteOnly));QCOMPARE(f.write(data),data.size());
}
struct Fixture {
    QTemporaryDir dir;
    Options options;
    Fixture() {
        options={dir.path()+"/photos",dir.path()+"/project",dir.path()+"/engine",2,5};
        for(int i=0;i<13;++i) put(options.input+QString("/photo%1.jpg").arg(i),QByteArray("original photo ")+QByteArray::number(i));
        for(const auto& name:{"VERSION","run.py","settings.yaml","pixi.lock"}) put(options.engine+"/"+name,"fixture\n");
        QDir().mkpath(QFileInfo(pythonPath(options)).absolutePath());
        QFile::copy(QString::fromUtf8(ODM_TEST_ENGINE),pythonPath(options));
        QFile::setPermissions(pythonPath(options),QFile::ReadOwner|QFile::WriteOwner|QFile::ExeOwner);
    }
};
class Jobs:public QObject {
    Q_OBJECT
private slots:
    void cleanup() {qunsetenv("ODM_TEST_MODE");}
    void concurrencyMatchesHardware() {
        Options o;o.threads=256;
        const auto args=arguments(o);
        const int count=qMax(1,QThread::idealThreadCount());
        QCOMPARE(args[args.indexOf("--max-concurrency")+1].toInt(),count);
        QCOMPARE(engineEnvironment(o).value("OMP_NUM_THREADS").toInt(),count);
    }
    void standardQuality() {
        QCOMPARE(Options{}.resolution,2.3);
        Fixture f;const auto a=arguments(f.options);
        QVERIFY(a.contains("--skip-3dmodel"));QVERIFY(a.contains("--no-gpu"));
        QVERIFY(!a.contains("--fast-orthophoto"));QVERIFY(!a.contains("--skip-report"));
        const QMap<QString,QString> expected={{"--feature-type","dspsift"},{"--feature-quality","ultra"},{"--min-num-features","24000"},{"--pc-quality","ultra"},{"--matcher-type","flann"},{"--sfm-algorithm","incremental"}};
        for(auto it=expected.begin();it!=expected.end();++it) QCOMPARE(a.value(a.indexOf(it.key())+1),it.value());
        const auto env=engineEnvironment(f.options);QCOMPARE(env.value("OMP_NUM_THREADS"),"2");QCOMPARE(env.value("OPENBLAS_NUM_THREADS"),"1");
        QCOMPARE(env.value("ODM_OFFLINE"),"1");QCOMPARE(env.value("PROJ_NETWORK"),"OFF");
    }
    void completeAndRerender() {
        Fixture f;Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(done[0][0].toBool());
        const auto project=readJson(f.options.output+"/project.json");QCOMPARE(project["state"].toString(),"complete");QCOMPARE(project["photo_count"].toInt(),3);
        QFile staged(f.options.output+"/flight/images/photo0.jpg");QVERIFY(staged.open(QIODevice::ReadOnly));QCOMPARE(staged.readAll(),QByteArray("original photo 0"));
        done.clear();f.options.resolution=2;p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(done[0][0].toBool());
        const auto command=readJson(f.options.output+"/project.json")["command"].toArray();QStringList a;for(const auto& item:command)a<<item.toString();
        QCOMPARE(a.value(a.indexOf("--rerun-from")+1),"odm_orthophoto");
    }
    void changedInputsPreserveResults() {
        Fixture f;Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(done[0][0].toBool());
        put(f.options.input+"/photo0.jpg","modified");done.clear();p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(!done[0][0].toBool());
        QCOMPARE(readJson(f.options.output+"/project.json")["state"].toString(),"complete");
    }
    void deduplicateThenKeepEverySixth() {
        Fixture f;put(f.options.input+"/photo0-copy.jpg","original photo 0");
        Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(done[0][0].toBool());
        const auto report=readJson(f.options.output+"/project.json");QCOMPARE(report["source_count"].toInt(),14);QCOMPARE(report["duplicate_count"].toInt(),1);QCOMPARE(report["photo_count"].toInt(),3);
        const auto photos=report["photos"].toArray();QVERIFY(photos[1].toObject()["source"].toString().endsWith("/photo6.jpg"));QVERIFY(photos[2].toObject()["source"].toString().endsWith("/photo12.jpg"));
    }
    void changedEngineRefused() {
        Fixture f;Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));
        put(f.options.engine+"/run.py","changed engine");done.clear();p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(!done[0][0].toBool());
    }
    void preparationManifestSurvivesInterruption() {
        Fixture f;Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));
        QVERIFY(writeJson(f.options.output+"/project.json",{{"application","odm-fedora"},{"state","preparing"}}));
        put(f.options.input+"/photo0.jpg","changed after incomplete copy");done.clear();p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(!done[0][0].toBool());
    }
    void failureResumesStage() {
        Fixture f;qputenv("ODM_TEST_MODE","fail");Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(!done[0][0].toBool());
        QCOMPARE(readJson(f.options.output+"/project.json")["stage"].toString(),"opensfm");
        qunsetenv("ODM_TEST_MODE");done.clear();p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(done[0][0].toBool());
        const auto command=readJson(f.options.output+"/project.json")["command"].toArray();QVERIFY(command.contains("--rerun-from"));QVERIFY(command.contains("opensfm"));
    }
    void cancelAndLock() {
        Fixture f;qputenv("ODM_TEST_MODE","wait");Pipeline p,second;QSignalSpy done(&p,&Pipeline::finished),other(&second,&Pipeline::finished);p.start(f.options);
        QTRY_COMPARE_WITH_TIMEOUT(readJson(f.options.output+"/project.json")["stage"].toString(),QString("opensfm"),10000);
        second.start(f.options);QCOMPARE(other.size(),1);QVERIFY(!other[0][0].toBool());QVERIFY(other[0][1].toString().contains("another window"));
        p.cancel();QVERIFY(done.wait(6000));QVERIFY(!p.running());QCOMPARE(readJson(f.options.output+"/project.json")["state"].toString(),"stopped");
        qunsetenv("ODM_TEST_MODE");done.clear();p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(done[0][0].toBool());
    }
    void missingOutputFails() {
        Fixture f;qputenv("ODM_TEST_MODE","missing");Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QVERIFY(done.wait(10000));QVERIFY(!done[0][0].toBool());
    }
    void linuxDescendantCleanup() {
#ifdef Q_OS_LINUX
        Fixture f;qputenv("ODM_TEST_MODE","child");Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);
        QTRY_VERIFY_WITH_TIMEOUT(QFileInfo::exists(f.options.output+"/child.pid"),10000);
        QFile pidFile(f.options.output+"/child.pid");QVERIFY(pidFile.open(QIODevice::ReadOnly));const auto child=pidFile.readAll().toLongLong();QVERIFY(child>0);
        p.cancel();QVERIFY(done.wait(6000));
        auto alive=[child] {QFile stat(QString("/proc/%1/stat").arg(child));if(!stat.open(QIODevice::ReadOnly))return false;const auto data=stat.readAll();return data.mid(data.lastIndexOf(')')+2,1)!="Z";};
        QTRY_VERIFY_WITH_TIMEOUT(!alive(),4000);
#else
        QSKIP("Linux /proc process cleanup must be verified on the Fedora target.");
#endif
    }
    static QByteArray http(quint16 port,const QByteArray& method,const QByteArray& path,const QByteArray& body={},const QByteArray& token={},const QByteArray& host={}) {
        QTcpSocket s;QEventLoop loop;QTimer timeout;timeout.setSingleShot(true);
        QByteArray req=method+" "+path+" HTTP/1.1\r\nHost: "+(host.isEmpty()?"127.0.0.1:"+QByteArray::number(port):host)+"\r\nContent-Length: "+QByteArray::number(body.size())+"\r\n";
        if(!token.isEmpty()) req+="X-ODM-Token: "+token+"\r\n";
        QByteArray out;QObject::connect(&s,&QTcpSocket::connected,&loop,[&]{s.write(req+"\r\n"+body);});
        QObject::connect(&s,&QTcpSocket::readyRead,&loop,[&]{out+=s.readAll();});
        QObject::connect(&s,&QTcpSocket::disconnected,&loop,&QEventLoop::quit);
        QObject::connect(&timeout,&QTimer::timeout,&loop,&QEventLoop::quit);
        timeout.start(5000);s.connectToHost(QHostAddress::LocalHost,port);loop.exec();out+=s.readAll();return out;
    }
    static QJsonObject bodyOf(const QByteArray& response) {return QJsonDocument::fromJson(response.mid(response.indexOf("\r\n\r\n")+4)).object();}
    void localhostWebsite() {
        Fixture f;put(f.options.engine+"/fedora/web/index.html","<!doctype html><html lang=\"en\">Offline interface</html>");
        Server known(f.options);QVERIFY(known.listen(0));const auto knownPort=known.port();
        auto response=http(knownPort,"GET","/api/state");QVERIFY(response.startsWith("HTTP/1.1 200"));
        const auto state=bodyOf(response);const auto token=state["token"].toString().toUtf8();QVERIFY(!token.isEmpty());QVERIFY(!state["running"].toBool());
        QVERIFY(http(knownPort,"GET","/api/state",{},{},"evil.example:80").startsWith("HTTP/1.1 403"));
        QVERIFY(http(knownPort,"POST","/api/start","{}").startsWith("HTTP/1.1 403"));
        QVERIFY(http(knownPort,"GET","/").contains("<html"));
        const auto session=bodyOf(http(knownPort,"POST","/api/upload-session","{\"count\":13}",token));const auto id=session["id"].toString().toUtf8();QVERIFY(!id.isEmpty());
        QVERIFY(http(knownPort,"POST","/api/upload-finish","{\"id\":\""+id+"\"}",token).startsWith("HTTP/1.1 400"));
        QVERIFY(http(knownPort,"POST","/api/upload?id="+id+"&name=../x.jpg","data",token).startsWith("HTTP/1.1 400"));
        for(int i=0;i<13;++i) QVERIFY(http(knownPort,"POST","/api/upload?id="+id+"&name=sub/photo"+QByteArray::number(i)+".jpg","uploaded photo "+QByteArray::number(i),token).startsWith("HTTP/1.1 200"));
        QVERIFY(http(knownPort,"POST","/api/upload-finish","{\"id\":\""+id+"\"}",token).startsWith("HTTP/1.1 200"));
        QFile staged(session["input"].toString()+"/sub/photo3.jpg");QVERIFY(staged.open(QIODevice::ReadOnly));QCOMPARE(staged.readAll(),QByteArray("uploaded photo 3"));
        const QJsonObject start={{"input",session["input"].toString()},{"output",f.options.output},{"threads",2},{"resolution",5.0}};
        response=http(knownPort,"POST","/api/start",QJsonDocument(start).toJson(QJsonDocument::Compact),token);QVERIFY2(response.startsWith("HTTP/1.1 200"),response.constData());
        QTRY_VERIFY_WITH_TIMEOUT(bodyOf(http(knownPort,"GET","/api/state"))["success"].toBool(),10000);
        const auto done=bodyOf(http(knownPort,"GET","/api/state"));QCOMPARE(done["photo_count"].toInt(),3);QVERIFY(done["log"].toString().contains("opensfm"));
        QVERIFY(http(knownPort,"GET","/api/result").startsWith("HTTP/1.1 200"));
        QDir(session["input"].toString()).removeRecursively();
    }
    void validatesFolders() {
        Fixture f;auto o=f.options;o.output=o.input+"/nested";QVERIFY(!validate(o).isEmpty());
        o=f.options;o.output=f.dir.path()+"/unsafe$path";QVERIFY(!validate(o).isEmpty());
        o=f.options;o.threads=0;QVERIFY(!validate(o).isEmpty());
        QDir().mkpath(f.options.output);put(f.options.output+"/.user-file","preserve");Pipeline p;QSignalSpy done(&p,&Pipeline::finished);p.start(f.options);QCOMPARE(done.size(),1);QVERIFY(!done[0][0].toBool());
    }
};
QTEST_GUILESS_MAIN(Jobs)
#include "test_pipeline.moc"
