"""Launch upstream OpenSfM with the validated bounded Python feature scheduler."""
from pathlib import Path
import os, runpy, sys
ROOT=Path(__file__).resolve().parents[1]
ENGINE=ROOT/'SuperBuild/install/bin/opensfm'
sys.path[:0]=[str(ROOT),str(ENGINE)]
sys.path.insert(0, str(ROOT/'fedora'))
from terrain_runtime import enabled, install_feature_cache
cache = None
if enabled() and len(sys.argv) > 1 and sys.argv[1] in ('match_features', 'reconstruct'):
    cache = install_feature_cache()
if os.environ.get('ADM_PARALLEL','1')!='0':
    from opensfm import features_processing
    from parallel_runtime.opensfm import extract
    features_processing.run_features_processing=extract
try:
    runpy.run_path(str(ENGINE/'bin/opensfm_main.py'),run_name='__main__')
finally:
    if cache is not None:
        print('Ultra decoded feature cache:', cache.report(), flush=True)
