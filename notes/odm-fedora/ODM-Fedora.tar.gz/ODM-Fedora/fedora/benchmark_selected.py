"""Benchmark already-selected photographs directly: no deduplication or sampling."""
import argparse,json,os,signal,subprocess,sys,time
from pathlib import Path

def process_rows():
    text=subprocess.check_output(['ps','-axo','pid=,ppid=,rss=,pcpu=,comm='],text=True)
    rows={}
    for line in text.splitlines():
        fields=line.split(None,4)
        if len(fields)==5:
            try:rows[int(fields[0])]=(int(fields[1]),int(fields[2])*1024,float(fields[3]),fields[4])
            except ValueError:pass
    return rows

def descendants(pid,rows):
    result={pid}
    while True:
        more={p for p,row in rows.items() if row[0] in result}
        if more<=result:return result
        result|=more

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--threads',type=int,default=8);p.add_argument('--expect-images',type=int,default=36);p.add_argument('--pause-pid',type=int);a=p.parse_args()
    root=Path(__file__).resolve().parents[1];prefix=root/'.pixi/envs/default';source=a.input.resolve();project=a.output.resolve()
    files=sorted((f for f in source.rglob('*') if f.is_file() and f.suffix.lower() in {'.jpg','.jpeg','.png','.tif','.tiff'}),key=lambda f:str(f).lower())
    if len(files)!=a.expect_images:raise ValueError(f'Expected {a.expect_images} photos; found {len(files)}')
    project.mkdir(parents=True,exist_ok=False);images=project/'flight/images';images.mkdir(parents=True)
    manifest=[]
    for i,f in enumerate(files):
        name=f.name
        if (images/name).exists():name=f'{i:05d}_{name}'
        (images/name).symlink_to(f);manifest.append({'name':name,'source':str(f),'bytes':f.stat().st_size})
    report={'input':str(source),'photo_count':len(files),'deduplication':False,'sampling':False,'photos':manifest,'threads':a.threads,'quality':'ultra','resolution_cm_per_pixel':2.3,'status':'starting','paused_pid':a.pause_pid,'peak_process_tree_rss_bytes':0,'stage_seconds':{},'full_pipeline_pixel_parity_tested':False,
            'terrain_runtime':os.environ.get('ODM_TERRAIN_RUNTIME','1')!='0',
            'experimental_hybrid':os.environ.get('ODM_HYBRID')=='1',
            'full_report':os.environ.get('ODM_FULL_REPORT','0')=='1' or os.environ.get('ODM_TERRAIN_RUNTIME','1')=='0'}
    report_file=project/'benchmark.json'
    def save():
        temp=report_file.with_suffix('.json.tmp');temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(report_file)
    save();env=dict(os.environ,CONDA_PREFIX=str(prefix),PATH=f'{prefix}/bin:{root}/SuperBuild/install/bin:'+os.environ['PATH'],PROJ_DATA=str(prefix/'share/proj'),GDAL_DATA=str(prefix/'share/gdal'),PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',OMP_NUM_THREADS=str(a.threads),OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',ODM_FSR_BACKEND='cpu',ODM_NO_GPU='1',ODM_OFFLINE='1',PROJ_NETWORK='OFF',no_ansiesc='1')
    for key in ['PYTHONPATH','PYTHONHOME','DYLD_LIBRARY_PATH','LD_LIBRARY_PATH']:env.pop(key,None)
    cmd=[str(prefix/'bin/python'),'-u',str(root/'fedora/quality_run.py'),'--project-path',str(project),'flight','--skip-3dmodel','--no-gpu','--max-concurrency',str(a.threads),'--orthophoto-resolution','2.3','--feature-type','dspsift','--feature-quality','ultra','--min-num-features','24000','--matcher-type','flann','--pc-quality','ultra','--mesh-size','500000','--mesh-octree-depth','12','--sfm-algorithm','incremental']
    report['command']=cmd;child=None;paused=False;paused_command=None;start=time.perf_counter();last_save=start;current_stage=None;stage_start=start
    def cancel(signum,frame):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,cancel);signal.signal(signal.SIGINT,cancel)
    try:
        if a.pause_pid:
            paused_command=subprocess.check_output(['ps','-p',str(a.pause_pid),'-o','command='],text=True).strip()
            if str(root/'SuperBuild/install/bin/texrecon') not in paused_command:raise ValueError('Pause target is not this installation\'s texrecon')
            os.kill(a.pause_pid,signal.SIGSTOP);paused=True;report['paused_command']=paused_command
        with (project/'process.log').open('w') as log,(project/'process.log').open() as reader:
            child=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            report.update(status='running',pid=child.pid);save();print(f'Started {len(files)} photos, no deduplication/sampling. PID {child.pid}',flush=True)
            while child.poll() is None:
                now=time.perf_counter();rows=process_rows();tree=descendants(child.pid,rows)
                rss=sum(rows[q][1] for q in tree if q in rows);report['peak_process_tree_rss_bytes']=max(report['peak_process_tree_rss_bytes'],rss);report['current_process_tree_rss_bytes']=rss
                for line in reader.readlines():
                    if '[INFO]' in line and 'Running ' in line and line.rstrip().endswith(' stage'):
                        stage=line.split('Running ',1)[1].rsplit(' stage',1)[0]
                        if current_stage:report['stage_seconds'][current_stage]=now-stage_start
                        current_stage=stage;stage_start=now;report['stage']=stage;print(f'{now-start:.1f}s: {stage}',flush=True)
                report['elapsed_seconds']=now-start
                if now-last_save>=5:save();last_save=now
                time.sleep(1)
            if current_stage:report['stage_seconds'][current_stage]=time.perf_counter()-stage_start
            report.update(status='complete' if child.returncode==0 else 'failed',exit_code=child.returncode,elapsed_seconds=time.perf_counter()-start)
    except BaseException as exc:
        report.update(status='interrupted' if isinstance(exc,KeyboardInterrupt) else 'failed',error=str(exc),elapsed_seconds=time.perf_counter()-start)
        if child and child.poll() is None:
            for pid in sorted(descendants(child.pid,process_rows()),reverse=True):
                try:os.kill(pid,signal.SIGTERM)
                except ProcessLookupError:pass
            try:child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                for pid in sorted(descendants(child.pid,process_rows()),reverse=True):
                    try:os.kill(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
        raise
    finally:
        if paused:
            try:
                command=subprocess.check_output(['ps','-p',str(a.pause_pid),'-o','command='],text=True).strip()
                if command==paused_command:os.kill(a.pause_pid,signal.SIGCONT);report['paused_job_resumed']=True
            except (ProcessLookupError,subprocess.CalledProcessError):report['paused_job_resumed']='process already exited'
        save()
    print(json.dumps({k:v for k,v in report.items() if k not in ('photos','command')},indent=2),flush=True)
    return report['exit_code']
if __name__=='__main__':sys.exit(main())
