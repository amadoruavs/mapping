"""Run the unchanged ODM engine, then generate a separate FSR display GeoTIFF."""
import os
import json
from pathlib import Path
import runpy
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from terrain_runtime import enabled
if os.environ.get('ODM_HYBRID')=='1':
    print('EXPERIMENTAL hybrid: middle-pass flat-region refinement may change geometry. Use a new project.',flush=True)
    library=ROOT/'parallel_runtime/kernels/libadm_hip.so'
    if library.exists():os.environ.setdefault('ADM_HIP_KERNEL_LIBRARY',str(library))
if enabled():
    # PDF/diagnostic chart generation is independent of the orthophoto pixels.
    # Keep it available explicitly for survey/quality-report workflows.
    if os.environ.get('ODM_FULL_REPORT', '0') != '1' and '--skip-report' not in sys.argv:
        sys.argv.append('--skip-report')
        print('Ultra map profile: omitting PDF/diagnostic plots; geometry and dense checks retained.', flush=True)
# Avoid idle OpenMP workers burning CPU while another worker owns a critical section.
os.environ.setdefault('OMP_WAIT_POLICY','PASSIVE')
os.environ.setdefault('KMP_BLOCKTIME','0')
# Also protect launches from an already-running desktop server or direct CLI.
if '--max-concurrency' in sys.argv:
    index = sys.argv.index('--max-concurrency') + 1
    requested = int(sys.argv[index])
    workers = max(1, min(requested, os.cpu_count() or 1))
    sys.argv[index] = str(workers)
    os.environ['OMP_NUM_THREADS'] = str(workers)
    os.environ['OMP_MAX_ACTIVE_LEVELS'] = '1'
    if workers != requested:
        print(f'CPU workers limited to {workers} hardware threads (requested {requested}).', flush=True)
try:
    runpy.run_path(str(ROOT/'run.py'),run_name='__main__')
except SystemExit as exc:
    if exc.code not in (None,0):raise
from finish.fsr import finish
args=sys.argv[1:]
project=Path(args[args.index('--project-path')+1])
threads=int(args[args.index('--max-concurrency')+1])
reconstruction_file=project/'flight/opensfm/reconstruction.json'
if reconstruction_file.is_file():
    reconstructions=json.loads(reconstruction_file.read_text())
    registered={name for reconstruction in reconstructions for name in reconstruction.get('shots',{})}
    image_list=project/'flight/opensfm/image_list.txt'
    expected={Path(line).name for line in image_list.read_text().splitlines() if line.strip()}
    summary=dict(input_photos=len(expected),registered_photos=len(registered),
                 components=len(reconstructions),
                 sparse_points=sum(len(r.get('points',{})) for r in reconstructions),
                 unregistered_photos=sorted(expected-registered),
                 full_report='--skip-report' not in args)
    (project/'flight/quality_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(f'[quality] Registered {len(registered)}/{len(expected)} photographs in {len(reconstructions)} component(s).',flush=True)
    if expected-registered:
        print('[quality] Some photographs did not register; inspect quality_summary.json for missing coverage.',flush=True)
folder=project/'flight/odm_orthophoto'
finish(folder/'odm_orthophoto.tif',folder/'odm_orthophoto_fsr2x.tif',
       os.environ.get('ODM_FSR_BACKEND','auto'),threads)
