"""Controlled degraded-photo parity and robust matching tests; not survey validation."""
import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT/'SuperBuild/install/bin/opensfm')]


def geometric_outliers():
    import cv2
    import numpy as np
    from opensfm import config, matching
    rng = np.random.default_rng(365)
    # Non-planar points include ground and elevated objects at different depths.
    xyz = rng.uniform([-15, -10, 30], [15, 10, 60], (1000, 3))
    rotation, _ = cv2.Rodrigues(np.array([0.03, -0.06, 0.02]))
    second = xyz @ rotation.T + [5., .4, .2]
    first_points = .65 * xyz[:, :2] / xyz[:, 2:]
    second_points = .65 * second[:, :2] / second[:, 2:]
    settings = config.default_config()
    reports = []
    for outlier_fraction, noise_pixels in [(0.15, 1.), (0.35, 2.), (0.50, 3.)]:
        p1 = first_points + rng.normal(0, noise_pixels/3840, first_points.shape)
        p2 = second_points + rng.normal(0, noise_pixels/3840, second_points.shape)
        count = int(len(p1)*outlier_fraction)
        p2[:count] = rng.uniform(-.4, .4, (count, 2))
        pairs = np.column_stack([np.arange(len(p1))]*2)
        cv2.setRNGSeed(42)
        _, accepted = matching.robust_match_fundamental(p1, p2, pairs, settings)
        indices = accepted[:, 0] if len(accepted) else np.array([], dtype=int)
        true_count = int(np.count_nonzero(indices >= count))
        precision = true_count / max(1, len(indices))
        recall = true_count / (len(p1)-count)
        reports.append(dict(outlier_fraction=outlier_fraction, coordinate_noise_pixels=noise_pixels,
                            accepted=len(indices), precision=precision, recall=recall,
                            passed=precision>=.97 and recall>=.80))
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, help='Existing OpenSfM project with original photographs')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    report = {'geometry_outliers': geometric_outliers(), 'scope': 'Controlled fixtures, not surveyed field accuracy or a new reconstruction algorithm'}
    if args.project:
        import cv2
        import numpy as np
        from opensfm import dataset
        from parallel_runtime.opensfm import extract
        source = dataset.DataSet(str(args.project.resolve()))
        names = sorted(source.images())[:4]
        if len(names) < 4:
            raise ValueError('Four source photographs are required')
        images = args.output/'degraded'
        images.mkdir()
        rng = np.random.default_rng(365)
        manifests = []
        for index, name in enumerate(names):
            rgb = source.load_image(name)
            if index == 0:
                rgb = np.clip(rgb.astype(float)+rng.normal(0, 10, rgb.shape), 0, 255).astype(np.uint8)
                change = 'Gaussian sensor noise sigma 10/255'
            elif index == 1:
                rgb = np.clip(rgb.astype(float)*.55+rng.normal(0, 5, rgb.shape), 0, 255).astype(np.uint8)
                change = '0.55 exposure multiplier plus noise sigma 5/255'
            elif index == 2:
                kernel = np.zeros((9, 9), np.float32); kernel[4] = 1/9
                rgb = cv2.filter2D(rgb, -1, kernel)
                change = 'nine-pixel horizontal motion blur'
            else:
                ok, encoded = cv2.imencode('.jpg', cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 55])
                if not ok:raise RuntimeError('JPEG encoding failed')
                rgb = cv2.cvtColor(cv2.imdecode(encoded, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)
                change = 'JPEG quality 55 compression'
            path = images/name
            if not cv2.imwrite(str(path), cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 100]):
                raise RuntimeError('Cannot write fixture')
            manifests.append(dict(name=name, change=change, width=rgb.shape[1], height=rgb.shape[0]))
        timings = {}
        original = os.environ.get('ODM_TERRAIN_RUNTIME')
        try:
            for variant in ['ordered', 'ready_first']:
                path = args.output/variant;path.mkdir()
                for name in ['camera_models.json', 'config.yaml']:
                    shutil.copy2(args.project/name, path/name)
                shutil.copytree(args.project/'exif', path/'exif')
                (path/'image_list.txt').write_text('\n'.join(str((images/name).resolve()) for name in names)+'\n')
                data = dataset.DataSet(str(path));data.config['processes']=2
                os.environ['ODM_TERRAIN_RUNTIME'] = '0' if variant=='ordered' else '1'
                start=time.perf_counter();extract(data, data.images(), True);timings[variant]=time.perf_counter()-start
        finally:
            if original is None:os.environ.pop('ODM_TERRAIN_RUNTIME', None)
            else:os.environ['ODM_TERRAIN_RUNTIME']=original
        a, b = [dataset.DataSet(str(args.output/v)) for v in ['ordered', 'ready_first']]
        counts = {}
        for name in names:
            first, second = a.load_features(name), b.load_features(name)
            for field in ['points','descriptors','colors']:
                np.testing.assert_array_equal(getattr(first,field),getattr(second,field))
            counts[name]=len(first.points)
        report['degraded_photos'] = dict(passed=True, fixtures=manifests, feature_counts=counts, timings=timings,
                                         bit_identical=['points','descriptors','colors'])
    report['passed'] = all(case['passed'] for case in report['geometry_outliers'])
    (args.output/'result.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    if not report['passed']:raise SystemExit(1)


if __name__ == '__main__':
    main()
