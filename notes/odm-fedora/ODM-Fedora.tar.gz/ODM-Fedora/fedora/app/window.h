#pragma once
#include "pipeline.h"
#include <QMainWindow>
class QLineEdit; class QDoubleSpinBox; class QSpinBox; class QPushButton;
class QLabel; class QProgressBar; class QPlainTextEdit; class QCloseEvent;
namespace odm {
class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    void setPaths(const QString& input, const QString& output);
protected:
    void closeEvent(QCloseEvent* event) override;
private:
    void run(); void restoreProject();
    Pipeline pipeline;
    QLineEdit *input, *output;
    QDoubleSpinBox *resolution;
    QSpinBox *threads;
    QWidget *settingsPage;
    QPushButton *start, *stop, *openResult;
    QLabel *message, *preview, *elapsed;
    QProgressBar* progress;
    QPlainTextEdit* logs;
    QElapsedTimer timer;
};
}
