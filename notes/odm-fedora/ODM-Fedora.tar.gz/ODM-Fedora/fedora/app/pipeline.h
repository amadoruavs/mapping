#pragma once
#include <QtCore>
#include <QUdpSocket>
#include <atomic>
#include <memory>
#include "process_tree.h"
namespace odm {
struct Options {
    QString input,output,engine;
    int threads=4;
    double resolution=2.3;
};
QString engineDirectory();
QString pythonPath(const Options&);
QStringList imagesIn(const QString&);
QStringList arguments(const Options&,const QString& rerun={});
QString validate(const Options&);
int recommendedThreads();
QJsonObject readJson(const QString&);
bool writeJson(const QString&,const QJsonObject&);
QProcessEnvironment engineEnvironment(const Options&);
class Pipeline:public QObject {
    Q_OBJECT
public:
    explicit Pipeline(QObject* parent=nullptr);
    ~Pipeline() override;
    void start(const Options&);
    void cancel();
    bool running() const {return active;}
    double elapsedSeconds() const {return active?timer.elapsed()/1000.0:report["last_run_seconds"].toDouble();}
signals:
    void status(QString,int,int);
    void log(QString);
    void finished(bool,QString);
private:
    void launch();void drain();void finish(bool,const QString&);void save(const QString&,const QString& = {});
    Options options;
    QProcess process;
    QUdpSocket progressSocket;
    QFile logFile;
    QElapsedTimer timer;
    QJsonObject report;
    QString pendingLog, stage, rerun;
    bool active=false,stopping=false,prepared=false;
    std::unique_ptr<QLockFile> lock;
    std::shared_ptr<std::atomic_bool> cancelled;
    QList<ProcessIdentity> stoppedChildren;
};
}
