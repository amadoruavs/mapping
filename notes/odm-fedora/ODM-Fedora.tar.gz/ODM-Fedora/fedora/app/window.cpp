#include "window.h"
#include <QtWidgets>
#include <QDesktopServices>
#include <QSettings>
#include <QThread>
namespace odm {
Window::Window() {
    setWindowTitle("ODM Desktop · Orthophotos"); resize(1150, 860); setMinimumSize(850, 680);
    setStyleSheet(R"(
      QMainWindow, QWidget#page { background:#f6f6f3; color:#202622; }
      QWidget { font-family: 'Noto Sans', 'Helvetica Neue', sans-serif; font-size:14px; }
      QLabel#title { font-size:30px; font-weight:600; }
      QLabel#eyebrow { color:#52605a; font-size:12px; letter-spacing:2px; }
      QLabel#muted { color:#64716a; }
      QLineEdit, QDoubleSpinBox, QSpinBox { background:white; padding:9px; border:1px solid #c7ceca; border-radius:5px; }
      QLineEdit:focus, QDoubleSpinBox:focus, QSpinBox:focus, QPushButton:focus { border:2px solid #245fca; }
      QPushButton { padding:10px 14px; border:1px solid #c7ceca; border-radius:5px; background:white; }
      QPushButton:hover { background:#ecefec; }
      QPushButton#primary { background:#245fca; color:white; border:0; font-weight:600; }
      QPushButton:disabled { color:#969e98; background:#e9ece8; }
      QProgressBar { background:#e1e6e0; border:0; border-radius:3px; height:6px; }
      QProgressBar::chunk { background:#245fca; border-radius:3px; }
      QPlainTextEdit { background:#202823; color:#d9e2db; border:0; padding:10px; font-family:Menlo,Consolas,monospace; font-size:11px; }
      QGroupBox { font-weight:600; border:1px solid #d9ded8; border-radius:6px; margin-top:18px; padding-top:15px; }
      QGroupBox::title { subcontrol-origin:margin; left:14px; padding:0 5px; }
    )");
    auto* page = new QWidget; page->setObjectName("page"); setCentralWidget(page);
    auto* root = new QVBoxLayout(page); root->setContentsMargins(28,24,28,20); root->setSpacing(16);
    auto* eyebrow = new QLabel("ODM  /  FEDORA DESKTOP"); eyebrow->setObjectName("eyebrow"); root->addWidget(eyebrow);
    auto* heading = new QHBoxLayout;
    auto* title = new QLabel("Photos to orthophoto"); title->setObjectName("title"); heading->addWidget(title); heading->addStretch();
    elapsed = new QLabel("Ready"); elapsed->setObjectName("muted"); heading->addWidget(elapsed); root->addLayout(heading);
    auto* subtitle = new QLabel("Full folders · remove exact duplicates · keep photos 1, 7, 13, … · ultra ODM reconstruction + FSR.");
    subtitle->setObjectName("muted"); subtitle->setWordWrap(true); root->addWidget(subtitle);
    auto* body = new QHBoxLayout; body->setSpacing(24); root->addLayout(body, 1);
    auto* scroll = new QScrollArea; scroll->setWidgetResizable(true); scroll->setFrameShape(QFrame::NoFrame);
    settingsPage = new QWidget; settingsPage->setObjectName("page"); scroll->setWidget(settingsPage);
    auto* controls = new QVBoxLayout(settingsPage); controls->setContentsMargins(0,0,8,0); controls->setSpacing(12);
    controls->setSizeConstraint(QLayout::SetMinimumSize); body->addWidget(scroll, 5);
    auto addFolder = [&](const QString& label, const QString& name, QLineEdit*& edit) {
        auto* text = new QLabel(label); controls->addWidget(text);
        auto* row = new QHBoxLayout; edit = new QLineEdit; edit->setObjectName(name); edit->setAccessibleName(label);
        text->setBuddy(edit); row->addWidget(edit, 1);
        auto* browse = new QPushButton("Browse…"); row->addWidget(browse); controls->addLayout(row);
        QLineEdit* field = edit;
        connect(browse, &QPushButton::clicked, this, [this, field, label]() {
            const auto selected = QFileDialog::getExistingDirectory(this, label, field->text());
            if (!selected.isEmpty()) { field->setText(selected); if (field == output) restoreProject(); }
        });
    };
    addFolder("Photo folder", "inputPath", input); input->setPlaceholderText("Folder of overlapping flight photos");
    addFolder("Project folder", "outputPath", output); output->setPlaceholderText("A new folder, or a saved project to resume");
    connect(output, &QLineEdit::editingFinished, this, &Window::restoreProject);
    auto* group = new QGroupBox("Map settings"); auto* form = new QFormLayout(group); form->setContentsMargins(14,20,14,14); form->setSpacing(12);
    form->addRow("Quality", new QLabel("Ultra + FSR 2×"));
    auto* qualityHelp = new QLabel("Full terrain reconstruction. GeoTIFF output for mapping and measurement."); qualityHelp->setWordWrap(true); qualityHelp->setObjectName("muted"); form->addRow(qualityHelp);
    resolution = new QDoubleSpinBox; resolution->setRange(.1,1000); resolution->setDecimals(1); resolution->setValue(2.3); resolution->setSuffix(" cm/px"); resolution->setObjectName("resolution"); form->addRow("Map resolution", resolution);
    auto* resolutionHelp = new QLabel("Smaller values create larger maps. Detail is limited by the original photos."); resolutionHelp->setWordWrap(true); resolutionHelp->setObjectName("muted"); form->addRow(resolutionHelp);
    threads = new QSpinBox; threads->setRange(1,qMax(1,QThread::idealThreadCount())); threads->setValue(recommendedThreads()); form->addRow("CPU threads", threads);
    auto* cpuHelp = new QLabel("Parallel CPU processing. The suggested thread count accounts for available memory."); cpuHelp->setWordWrap(true); cpuHelp->setObjectName("muted"); form->addRow(cpuHelp);
    controls->addWidget(group);
    message = new QLabel("Ready for a flight. Your original photos stay in their folder."); message->setWordWrap(true); message->setAccessibleName("Processing status"); root->addWidget(message);
    progress = new QProgressBar; progress->setRange(0,3); progress->setValue(0); progress->setTextVisible(false); root->addWidget(progress);
    auto* actions = new QHBoxLayout; start = new QPushButton("Build orthophoto"); start->setObjectName("primary"); stop = new QPushButton("Stop"); stop->setEnabled(false);
    actions->addWidget(start,1); actions->addWidget(stop); root->addLayout(actions); controls->addStretch();
    auto* viewer = new QVBoxLayout; body->addLayout(viewer,6);
    preview = new QLabel("Your map will appear here\n\nGeoTIFF + image preview"); preview->setAlignment(Qt::AlignCenter); preview->setWordWrap(true);
    preview->setMinimumSize(280,250); preview->setStyleSheet("background:#e9ede7; border:1px solid #d2d9d0; border-radius:8px; color:#68766b;"); viewer->addWidget(preview,1);
    openResult = new QPushButton("Open results folder"); openResult->setEnabled(false); viewer->addWidget(openResult);
    auto* logToggle = new QToolButton; logToggle->setText("Show processing log"); logToggle->setCheckable(true); root->addWidget(logToggle);
    logs = new QPlainTextEdit; logs->setReadOnly(true); logs->setMaximumBlockCount(1500); logs->setMaximumHeight(120); logs->hide(); root->addWidget(logs);
    connect(logToggle,&QToolButton::toggled,this,[this,logToggle](bool expanded) {logs->setVisible(expanded);logToggle->setText(expanded?"Hide processing log":"Show processing log");});
    auto* footer = new QLabel("OpenDroneMap · Native installation · No Docker"); footer->setObjectName("muted"); root->addWidget(footer);
    connect(start,&QPushButton::clicked,this,&Window::run);
    connect(stop,&QPushButton::clicked,&pipeline,&Pipeline::cancel);
    connect(openResult,&QPushButton::clicked,this,[this]() { const auto folder=output->text()+"/flight/odm_orthophoto"; QDesktopServices::openUrl(QUrl::fromLocalFile(QFileInfo(folder).isDir()?folder:output->text())); });
    connect(&pipeline,&Pipeline::status,this,[this](const QString& text,int done,int total) { message->setText(text); progress->setRange(0,total); progress->setValue(done); });
    connect(&pipeline,&Pipeline::log,this,[this](const QString& text) {
        const bool atEnd = logs->verticalScrollBar()->value() >= logs->verticalScrollBar()->maximum()-4;
        QTextCursor c(logs->document()); c.movePosition(QTextCursor::End); c.insertText(text);
        if (atEnd) logs->verticalScrollBar()->setValue(logs->verticalScrollBar()->maximum());
    });
    connect(&pipeline,&Pipeline::finished,this,[this,logToggle](bool ok,const QString& text) {
        start->setEnabled(true); stop->setEnabled(false); start->setText(ok ? "Update orthophoto" : "Start / resume");
        settingsPage->setEnabled(true);
        message->setText(text); message->setStyleSheet(ok ? "color:#256b39;" : "color:#a33727;");
        openResult->setEnabled(QFileInfo::exists(output->text()+"/project.json"));
        const QPixmap map(output->text()+"/preview.jpg");
        if (ok && !map.isNull()) preview->setPixmap(map.scaled(preview->size()-QSize(16,16),Qt::KeepAspectRatio,Qt::SmoothTransformation));
        else if (ok) preview->setText("Orthophoto ready\n\nOpen the results folder to view your GeoTIFF.");
        if (!ok && !logs->toPlainText().isEmpty()) logToggle->setChecked(true);
    });
    auto* clock = new QTimer(this); clock->start(1000);
    connect(clock,&QTimer::timeout,this,[this]() { if (pipeline.running()) elapsed->setText(QString::number(timer.elapsed()/1000)+" s elapsed"); });
    QSettings settings; input->setText(settings.value("input").toString()); output->setText(settings.value("output").toString()); restoreProject();
}
void Window::setPaths(const QString& in,const QString& out) { input->setText(in); output->setText(out); restoreProject(); }
void Window::restoreProject() {
    if (pipeline.running()) return;
    openResult->setEnabled(false); preview->setText("Your map will appear here\n\nGeoTIFF + image preview");
    message->setText("Ready for a flight. Your original photos stay in their folder.");message->setStyleSheet("");
    const auto project = readJson(output->text()+"/project.json"); if (project["application"].toString()!="odm-fedora") return;
    input->setText(project["input"].toString());
    threads->setValue(project["threads"].toInt(recommendedThreads())); resolution->setValue(project["resolution"].toDouble(2.3));
    message->setText("Saved project · "+project["state"].toString()+". Start to reuse completed work.");
    openResult->setEnabled(true);
    const QPixmap map(output->text()+"/preview.jpg");
    if (!map.isNull()) preview->setPixmap(map.scaled(480,420,Qt::KeepAspectRatio,Qt::SmoothTransformation));
}
void Window::run() {
    Options o; o.input=input->text(); o.output=output->text(); o.engine=engineDirectory();
    o.threads=threads->value(); o.resolution=resolution->value();
    QSettings settings; settings.setValue("input",o.input); settings.setValue("output",o.output);
    logs->clear(); message->setStyleSheet(""); start->setEnabled(false); stop->setEnabled(true);
    preview->setText("Processing your flight…\n\nThe map preview will appear when processing finishes.");
    settingsPage->setEnabled(false); openResult->setEnabled(false);
    timer.start(); pipeline.start(o);
}
void Window::closeEvent(QCloseEvent* event) {
    if (pipeline.running()) {
        pipeline.cancel(); message->setText("Stopping processing. Close the window after it stops."); event->ignore();
    } else event->accept();
}
}
