#include "window.h"
#include "server.h"
#include <QApplication>
#include <QCommandLineParser>
#include <QTimer>
#include <QThread>
#include <iostream>
#include <csignal>
static volatile std::sig_atomic_t interrupted=0;
static void stopRequested(int) {interrupted=1;}
int main(int argc,char** argv) {
    bool cli=false;
    for (int i=1;i<argc;++i) if (QStringList{"--cli","--serve","--doctor","--help","--version"}.contains(QString::fromLocal8Bit(argv[i]))) cli=true;
    std::unique_ptr<QCoreApplication> app;
    if (cli) app=std::make_unique<QCoreApplication>(argc,argv);
    else app=std::make_unique<QApplication>(argc,argv);
    app->setOrganizationName("ODMFedora"); app->setApplicationName("ODM Desktop"); app->setApplicationVersion("1.0.0");
    QCommandLineParser parser; parser.setApplicationDescription("Native C++ orthophoto workspace"); parser.addHelpOption(); parser.addVersionOption();
    parser.addOptions({{"cli","Process without a window"},{"serve","Serve the offline localhost website instead of a window"},{"port","Localhost website port","port","8765"},{"doctor","Check the native engine installation"},{"input","Source photo folder","path"},{"output","Project folder","path"},
      {"engine","ODM source and native installation root","path",odm::engineDirectory()},
      {"threads","Maximum CPU threads","count",QString::number(odm::recommendedThreads())},
      {"resolution","Orthophoto resolution in cm/pixel","cm","2.3"},{"ui-screenshot","Save a UI validation image and exit","path"}});
    parser.process(*app);
    odm::Options o; o.input=parser.value("input"); o.output=parser.value("output"); o.engine=QFileInfo(parser.value("engine")).absoluteFilePath();
    o.threads=parser.value("threads").toInt(); o.resolution=parser.value("resolution").toDouble();
    qputenv("ODM_ENGINE_ROOT",o.engine.toUtf8());
    if(parser.isSet("doctor")) {
        QProcess check; check.setProcessChannelMode(QProcess::ForwardedChannels); check.setWorkingDirectory(o.engine);
        check.setProcessEnvironment(odm::engineEnvironment(o)); check.start(odm::pythonPath(o),{o.engine+"/scripts/smoke.py"});
        if(!check.waitForStarted()) {std::cerr<<check.errorString().toStdString()<<". Run install-fedora.sh first.\n";return 1;}
        if(!check.waitForFinished(180000)) {check.kill();check.waitForFinished();std::cerr<<"Engine check timed out.\n";return 1;}
        return check.exitStatus()==QProcess::NormalExit?check.exitCode():1;
    }
    if (parser.isSet("serve")) {
        std::signal(SIGINT,stopRequested); std::signal(SIGTERM,stopRequested);
        odm::Server server(o);
        bool validPort=false;const auto requestedPort=parser.value("port").toUInt(&validPort);
        if(!validPort||requestedPort<1||requestedPort>65535){std::cerr<<"Port must be between 1 and 65535.\n";return 1;}
        const auto port=quint16(requestedPort);
        if(!server.listen(port)) {std::cerr<<"Cannot listen on 127.0.0.1:"<<port<<". Is ODM Desktop already serving?\n";return 1;}
        std::cout<<"ODM Desktop is serving offline at http://127.0.0.1:"<<port<<"/\nOpen that address in a browser on this computer. Press Ctrl+C to quit."<<std::endl;
        QTimer* signalTimer=new QTimer(&server); signalTimer->start(100);
        QObject::connect(signalTimer,&QTimer::timeout,&server,[&] {if(!interrupted) return; if(server.running()) server.stop(); else app->quit();});
        return app->exec();
    }
    odm::Pipeline pipeline;
    std::unique_ptr<odm::Window> window;
    if (parser.isSet("cli")) {
        std::signal(SIGINT,stopRequested); std::signal(SIGTERM,stopRequested);
        QTimer* signalTimer=new QTimer(&pipeline); signalTimer->start(100);
        QObject::connect(signalTimer,&QTimer::timeout,&pipeline,[&] {if(interrupted) pipeline.cancel();});
        QObject::connect(&pipeline,&odm::Pipeline::log,[](const QString& text) { std::cout<<text.toStdString()<<std::flush; });
        QObject::connect(&pipeline,&odm::Pipeline::status,[](const QString& text,int,int) { std::cout<<"\n"<<text.toStdString()<<"\n"<<std::flush; });
        QObject::connect(&pipeline,&odm::Pipeline::finished,app.get(),[&](bool ok,const QString& message) { std::cout<<message.toStdString()<<std::endl; app->exit(ok?0:1); });
        QTimer::singleShot(0,&pipeline,[&pipeline,o] { pipeline.start(o); });
    } else {
        window=std::make_unique<odm::Window>();
        if (parser.isSet("input") || parser.isSet("output")) window->setPaths(parser.value("input"),parser.value("output"));
        window->show();
        if (parser.isSet("ui-screenshot")) QTimer::singleShot(400,window.get(),[&] { app->exit(window->grab().save(parser.value("ui-screenshot"))?0:1); });
    }
    return app->exec();
}
