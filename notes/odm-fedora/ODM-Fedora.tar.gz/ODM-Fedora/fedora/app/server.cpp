#include "server.h"
#include <QTcpSocket>
#include <QUrlQuery>
namespace odm {
namespace {
void reply(QTcpSocket* socket,int status,const QByteArray& data,const QByteArray& type="application/json") {
    socket->write("HTTP/1.1 "+QByteArray::number(status)+(status==200?" OK\r\n":" Error\r\n")+"Content-Type: "+type+"\r\nContent-Length: "+QByteArray::number(data.size())+"\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n\r\n"+data);
    socket->disconnectFromHost();
}
void json(QTcpSocket* socket,const QJsonObject& data,int status=200){reply(socket,status,QJsonDocument(data).toJson(QJsonDocument::Compact));}
void error(QTcpSocket* socket,const QString& text,int status=400){json(socket,{{"error",text}},status);}
void stream(QTcpSocket* socket,const QString& path,const QByteArray& mime) {
    auto file=std::make_shared<QFile>(path);if(!file->open(QIODevice::ReadOnly)){error(socket,"Output is not available yet.",404);return;}
    socket->write("HTTP/1.1 200 OK\r\nContent-Type: "+mime+"\r\nContent-Length: "+QByteArray::number(file->size())+"\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n");
    auto pump=[socket,file] {while(socket->bytesToWrite()<262144&&!file->atEnd())socket->write(file->read(65536));if(file->atEnd())socket->disconnectFromHost();};
    QObject::connect(socket,&QTcpSocket::bytesWritten,socket,[pump](qint64){pump();});pump();
}
struct Request {QByteArray buffer,method;QUrl url;QString uploadId,uploadName;QMap<QByteArray,QByteArray> headers;qint64 remaining=-1;bool parsed=false,done=false;std::unique_ptr<QSaveFile> upload;};
}
Server::Server(Options defaults,QObject* parent):QObject(parent),options(std::move(defaults)) {
    token=QUuid::createUuid().toString(QUuid::WithoutBraces);
    uploadRoot=QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation)+"/incoming";
    if(options.output.isEmpty())options.output=QDir::homePath()+"/ODMProjects/flight-"+QDateTime::currentDateTime().toString("yyyyMMdd-HHmmss");
    connect(&server,&QTcpServer::newConnection,this,&Server::connection);
    connect(&pipeline,&Pipeline::log,this,[this](const QString& text){logs=(logs+text).right(100000);});
    connect(&pipeline,&Pipeline::status,this,[this](const QString& text,int done,int total){message=text;percent=total?done*100/total:0;});
    connect(&pipeline,&Pipeline::finished,this,[this](bool ok,const QString& text){success=ok;message=text;});
}
bool Server::listen(quint16 port){server.setMaxPendingConnections(16);return server.listen(QHostAddress::LocalHost,port);}
void Server::stop(){pipeline.cancel();}
QJsonObject Server::state() const {
    const auto report=readJson(options.output+"/project.json");
    return {{"token",token},{"running",pipeline.running()},{"success",success},{"message",message},{"percent",percent},{"log",logs},
        {"elapsed_seconds",pipeline.elapsedSeconds()},{"input",options.input},{"output",options.output},{"threads",options.threads},{"resolution",options.resolution},
        {"source_count",report["source_count"]},{"duplicate_count",report["duplicate_count"]},{"photo_count",report["photo_count"]},
        {"preview",QFileInfo::exists(options.output+"/preview.jpg")}};
}
void Server::connection() {
    while(server.hasPendingConnections()) {
        auto* socket=server.nextPendingConnection();socket->setParent(this);socket->setReadBufferSize(131072);
        connect(socket,&QTcpSocket::disconnected,socket,&QObject::deleteLater);
        auto request=std::make_shared<Request>();auto* timeout=new QTimer(socket);timeout->setSingleShot(true);timeout->start(120000);
        connect(timeout,&QTimer::timeout,socket,&QTcpSocket::abort);
        connect(socket,&QTcpSocket::readyRead,this,[this,socket,request,timeout] {
            auto& r=*request;if(r.done)return;timeout->start(120000);
            r.buffer+=socket->readAll();
            auto fail=[&](const QString& text,int status=400){r.done=true;error(socket,text,status);};
            if(!r.parsed) {
                const auto end=r.buffer.indexOf("\r\n\r\n");
                if(end<0){if(r.buffer.size()>16384)fail("Request headers too large.",413);return;}
                if(end>16384){fail("Request headers too large.",413);return;}
                const auto lines=r.buffer.left(end).split('\n');const auto first=lines[0].trimmed().split(' ');
                if(first.size()!=3){fail("Invalid request.");return;}
                r.method=first[0];r.url=QUrl::fromEncoded(first[1]);
                for(int i=1;i<lines.size();++i){const auto line=lines[i].trimmed();const auto colon=line.indexOf(':');if(colon>0)r.headers.insert(line.left(colon).toLower(),line.mid(colon+1).trimmed());}
                const auto host=r.headers.value("host");
                const auto suffix=":"+QByteArray::number(server.serverPort());
                if(host!="127.0.0.1"+suffix&&host!="localhost"+suffix){fail("Localhost access only.",403);return;}
                const auto origin=r.headers.value("origin");
                if(!origin.isEmpty()&&origin!="http://"+host){fail("Cross-origin requests are disabled.",403);return;}
                if(r.headers.contains("transfer-encoding")){fail("Chunked requests are not supported.");return;}
                if(r.method!="GET"&&r.method!="POST"){fail("Unsupported method.",405);return;}
                if(r.method=="POST"&&r.headers.value("x-odm-token")!=token.toUtf8()){fail("Refresh the page before continuing.",403);return;}
                bool valid=true;r.remaining=r.headers.contains("content-length")?r.headers.value("content-length").toLongLong(&valid):0;
                if(!valid||r.remaining<0||r.remaining>536870912){fail("Invalid file size (maximum 512 MB per photo).",413);return;}
                r.buffer.remove(0,end+4);r.parsed=true;
                if(r.method=="POST"&&r.url.path()=="/api/upload") {
                    if(pipeline.running()){fail("Wait for processing to finish.",409);return;}
                    QUrlQuery query(r.url);const auto id=query.queryItemValue("id");const auto name=query.queryItemValue("name",QUrl::FullyDecoded);
                    const auto parts=name.split('/');
                    if(!uploads.contains(id)||name.isEmpty()||name.startsWith('/')||name.contains('\\')||parts.contains("..")||parts.contains(".")||name.contains(QRegularExpression("[\\x00-\\x1f]"))){fail("Invalid upload path.");return;}
                    if(!QStringList{"jpg","jpeg","png","tif","tiff"}.contains(QFileInfo(name).suffix().toLower())){fail("Unsupported photo type.");return;}
                    const auto path=uploadRoot+"/"+id+"/"+name;
                    r.uploadId=id;r.uploadName=QDir::cleanPath(name);
                    if(!QDir().mkpath(QFileInfo(path).absolutePath())){fail("Cannot create the upload folder.");return;}
                    r.upload=std::make_unique<QSaveFile>(path);if(!r.upload->open(QIODevice::WriteOnly)){fail("Cannot save the photo.");return;}
                }else if(r.remaining>65536){fail("Request too large.",413);return;}
            }
            if(r.upload) {
                const auto count=qMin<qint64>(r.remaining,r.buffer.size());
                if(r.upload->write(r.buffer.constData(),count)!=count){fail("Photo upload failed: check free disk space.");return;}
                r.remaining-=count;r.buffer.remove(0,count);
                if(r.remaining==0){r.done=true;if(!r.upload->commit())error(socket,"Cannot save photo.");else {receivedUploads[r.uploadId].insert(r.uploadName);json(socket,{{"ok",true}});}}return;
            }
            if(r.buffer.size()<r.remaining)return;
            r.done=true;const auto path=r.url.path();
            if(r.method=="GET") {
                if(path=="/"){QFile page(options.engine+"/fedora/web/index.html");if(!page.open(QIODevice::ReadOnly)){error(socket,"Local website file is missing.",500);return;}reply(socket,200,page.readAll(),"text/html; charset=utf-8");}
                else if(path=="/api/state")json(socket,state());
                else if(path=="/api/preview")stream(socket,options.output+"/preview.jpg","image/jpeg");
                else if(path=="/api/fsr"&&success)stream(socket,options.output+"/flight/odm_orthophoto/odm_orthophoto_fsr2x.tif","image/tiff");
                else if(path=="/api/result"&&success)stream(socket,options.output+"/flight/odm_orthophoto/odm_orthophoto.tif","image/tiff");
                else error(socket,"Not found.",404);
                return;
            }
            if(path=="/api/stop"){pipeline.cancel();json(socket,{{"ok",true}});return;}
            if(pipeline.running()){error(socket,"A flight is already processing.",409);return;}
            if(path=="/api/upload-session") {
                const auto count=QJsonDocument::fromJson(r.buffer.left(r.remaining)).object()["count"].toInt();
                if(count<1||count>100000){error(socket,"Choose between 1 and 100,000 photos.");return;}
                const auto id=QUuid::createUuid().toString(QUuid::WithoutBraces);const auto folder=uploadRoot+"/"+id;
                if(!QDir().mkpath(folder)){error(socket,"Cannot create an upload folder.");return;}
                uploads.insert(id);expectedUploads[id]=count;json(socket,{{"id",id},{"input",folder}});return;
            }
            if(path=="/api/upload-finish") {
                const auto id=QJsonDocument::fromJson(r.buffer.left(r.remaining)).object()["id"].toString();
                if(!uploads.contains(id)||receivedUploads[id].size()!=expectedUploads[id]){error(socket,"The folder upload is incomplete.");return;}
                if(!writeJson(uploadRoot+"/"+id+"/.upload-complete.json",{{"count",expectedUploads[id]}})){error(socket,"Cannot save the upload manifest.");return;}
                uploads.remove(id);expectedUploads.remove(id);receivedUploads.remove(id);json(socket,{{"ok",true}});return;
            }
            if(path=="/api/start") {
                const auto body=QJsonDocument::fromJson(r.buffer.left(r.remaining)).object();
                auto next=options;next.input=body["input"].toString();next.output=body["output"].toString();next.threads=body["threads"].toInt();next.resolution=body["resolution"].toDouble();
                const auto canonicalInput=QFileInfo(next.input).canonicalFilePath();
                const auto canonicalUploads=QFileInfo(uploadRoot).canonicalFilePath();
                if(!canonicalUploads.isEmpty()&&canonicalInput.startsWith(canonicalUploads+"/")&&!QFileInfo::exists(canonicalInput+"/.upload-complete.json")){error(socket,"Finish uploading the full folder before processing.");return;}
                const auto problem=validate(next);if(!problem.isEmpty()){error(socket,problem);return;}
                options=next;logs.clear();success=false;pipeline.start(options);json(socket,state());return;
            }
            error(socket,"Not found.",404);
        });
    }
}
}
