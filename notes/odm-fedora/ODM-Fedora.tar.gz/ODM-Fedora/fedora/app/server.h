#pragma once
#include "pipeline.h"
#include <QTcpServer>
namespace odm {
class Server:public QObject {
public:
    explicit Server(Options defaults,QObject* parent=nullptr);
    bool listen(quint16 port);
    quint16 port() const {return server.serverPort();}
    void stop();
    bool running() const {return pipeline.running();}
private:
    QTcpServer server;
    Pipeline pipeline;
    Options options;
    QString token,logs,message="Ready for a flight.",uploadRoot;
    QSet<QString> uploads;
    QMap<QString,int> expectedUploads;
    QMap<QString,QSet<QString>> receivedUploads;
    int percent=0;
    bool success=false;
    void connection();
    QJsonObject state() const;
};
}
