#include "process_tree.h"
#ifdef Q_OS_UNIX
#include <signal.h>
#endif
namespace odm {
static QList<qint64> identity(qint64 pid) {
#ifdef Q_OS_LINUX
    QFile f(QString("/proc/%1/stat").arg(pid));if(!f.open(QIODevice::ReadOnly)) return {};
    const auto text=f.readAll();const auto parts=text.mid(text.lastIndexOf(')')+2).simplified().split(' ');
    // After comm: state(field3), ppid(field4), ..., starttime(field22).
    if(parts.size()>19) return {parts[1].toLongLong(),parts[19].toLongLong()};
#else
    Q_UNUSED(pid)
#endif
    return {};
}
QList<ProcessIdentity> descendants(qint64 root) {
    QList<ProcessIdentity> result;
#ifdef Q_OS_LINUX
    QMap<qint64,QList<qint64>> table;
    for(const auto& dir:QDir("/proc").entryList(QDir::Dirs|QDir::NoDotAndDotDot)) {
        bool ok;const auto pid=dir.toLongLong(&ok);if(!ok) continue;
        const auto id=identity(pid);if(!id.isEmpty()) table[pid]=id;
    }
    QSet<qint64> parents{root}; bool added=true;
    while(added) {
        added=false;
        for(auto it=table.begin();it!=table.end();++it)
            if(parents.contains(it.value()[0])&&!parents.contains(it.key())) {parents.insert(it.key());result.prepend({it.key(),it.value()[1]});added=true;}
    }
#else
    Q_UNUSED(root)
#endif
    return result;
}
void signalProcesses(const QList<ProcessIdentity>& processes,int signal) {
#ifdef Q_OS_LINUX
    for(const auto& p:processes) {
        const auto id=identity(p.pid);
        if(id.size()==2 && id[1]==p.born) ::kill(pid_t(p.pid),signal);
    }
#else
    Q_UNUSED(processes) Q_UNUSED(signal)
#endif
}
}
