#include "pipeline.h"
#include <QtConcurrent>
#include <QImageReader>
#include <QImage>
#include <stdexcept>
#include <cmath>
#include <algorithm>
#ifdef Q_OS_UNIX
#include <signal.h>
#endif
namespace odm {
static const QStringList stages={"dataset","split","merge","opensfm","openmvs","odm_filterpoints","odm_meshing","mvs_texturing","odm_georeferencing","odm_dem","odm_orthophoto","odm_report","odm_postprocess"};
static const QStringList labels={"Read photos","Plan reconstruction","Merge subprojects","Calibrate cameras","Reconstruct terrain","Filter points","Build map surface","Texture map surface","Georeference map","Prepare elevation","Render orthophoto","Create report","Finish outputs"};
QJsonObject readJson(const QString& path) {QFile f(path);if(!f.open(QIODevice::ReadOnly)) return {};return QJsonDocument::fromJson(f.readAll()).object();}
bool writeJson(const QString& path,const QJsonObject& value) {
    QSaveFile f(path);const auto bytes=QJsonDocument(value).toJson();
    return f.open(QIODevice::WriteOnly)&&f.write(bytes)==bytes.size()&&f.commit();
}
QString engineDirectory() {return qEnvironmentVariable("ODM_ENGINE_ROOT",QString::fromUtf8(ODM_DEFAULT_ENGINE_ROOT));}
QString pythonPath(const Options& o) {return QDir(o.engine).filePath(".pixi/envs/default/bin/python");}
static int effectiveThreads(int requested) {
    return qBound(1,requested,qMax(1,QThread::idealThreadCount()));
}
int recommendedThreads() {
    int threads=qMax(1,qMin(8,QThread::idealThreadCount()));
    QFile mem("/proc/meminfo");
    if(mem.open(QIODevice::ReadOnly)) {
        const auto match=QRegularExpression("MemAvailable:\\s+(\\d+)").match(QString::fromUtf8(mem.readAll()));
        if(match.hasMatch()) threads=qMin(threads,qMax(1,int((match.captured(1).toLongLong()/1048576.0-8)/3)));
    }
    return threads;
}
static QString resolved(const QString& path) {
    QFileInfo f(path);if(f.exists()) return f.canonicalFilePath();
    const auto parent=f.absoluteDir().absolutePath();if(parent==f.absoluteFilePath()) return parent;
    return QDir(resolved(parent)).filePath(f.fileName());
}
static bool shellUnsafe(const QString& s) {return s.contains(QRegularExpression("[\\x00-\\x1f\\\"'`$\\\\]"));}
QString validate(const Options& o) {
    if(!QFileInfo(o.input).isDir()) return "Choose an existing photo folder.";
    if(o.output.trimmed().isEmpty()) return "Choose a project folder.";
    const auto in=resolved(o.input),out=resolved(o.output);
    if(out==in||out.startsWith(in+"/")) return "Choose a project folder outside the source photos.";
    if(shellUnsafe(out)||shellUnsafe(resolved(o.engine))) return "ODM project and installation paths cannot contain quotes, backslashes, dollar signs, backticks, or control characters.";
    if(o.threads<1||o.threads>256) return "Choose between 1 and 256 CPU threads.";
    if(!std::isfinite(o.resolution)||o.resolution<.1||o.resolution>1000) return "Resolution must be between 0.1 and 1000 cm/pixel.";
    if(!QFileInfo(pythonPath(o)).isExecutable()||!QFileInfo::exists(o.engine+"/run.py")) return "The ODM engine is not installed. Run install-fedora.sh first.";
    return {};
}
QStringList imagesIn(const QString& folder) {
    QStringList files;QDirIterator it(folder,QDir::Files|QDir::Readable,QDirIterator::Subdirectories);
    const QStringList extensions={"jpg","jpeg","png","tif","tiff"};
    while(it.hasNext()) {it.next();if(extensions.contains(it.fileInfo().suffix().toLower())&&!it.fileInfo().completeBaseName().endsWith("_mask")) files<<it.filePath();}
    QCollator order{QLocale(QLocale::English)};order.setNumericMode(true);order.setCaseSensitivity(Qt::CaseInsensitive);
    std::stable_sort(files.begin(),files.end(),[&](const QString& a,const QString& b){const auto comparison=order.compare(a,b);return comparison==0?a<b:comparison<0;});return files;
}
QStringList arguments(const Options& o,const QString& rerun) {
    // Quality-first reconstruction; CPU concurrency leaves RAM for the shared-memory APU.
    QStringList result={"-u",QDir(o.engine).filePath("fedora/quality_run.py"),"--project-path",o.output,"flight",
        "--skip-3dmodel","--no-gpu","--max-concurrency",QString::number(effectiveThreads(o.threads)),
        "--orthophoto-resolution",QString::number(o.resolution,'g',10),
        "--feature-type","dspsift","--feature-quality","ultra","--min-num-features","24000",
        "--matcher-type","flann","--pc-quality","ultra","--mesh-size","500000","--mesh-octree-depth","12","--sfm-algorithm","incremental"};
    if(!rerun.isEmpty()) result<<"--rerun-from"<<rerun;
    return result;
}
QProcessEnvironment engineEnvironment(const Options& o) {
    auto env=QProcessEnvironment::systemEnvironment();const auto prefix=QDir(o.engine).filePath(".pixi/envs/default");
    env.insert("CONDA_PREFIX",prefix);
    env.insert("PATH",prefix+"/bin:"+o.engine+"/SuperBuild/install/bin:"+env.value("PATH"));
    env.insert("LD_LIBRARY_PATH",o.engine+"/SuperBuild/install/lib:"+prefix+"/lib");
    env.insert("PROJ_DATA",prefix+"/share/proj");env.insert("GDAL_DATA",prefix+"/share/gdal");
    env.insert("PYTHONNOUSERSITE","1");env.remove("PYTHONHOME");env.remove("PYTHONPATH");
    env.insert("OMP_NUM_THREADS",QString::number(effectiveThreads(o.threads)));env.insert("OMP_MAX_ACTIVE_LEVELS","1");
    // Prevent BLAS from creating a second thread pool inside each ODM worker.
    env.insert("OPENBLAS_NUM_THREADS","1");env.insert("MKL_NUM_THREADS","1");
    env.insert("ODM_NO_GPU","1");env.insert("no_ansiesc","1");env.insert("PYTHONUNBUFFERED","1");
    env.insert("ODM_OFFLINE","1");env.insert("PROJ_NETWORK","OFF");
    return env;
}
static QByteArray fileHash(const QString& path,const std::shared_ptr<std::atomic_bool>& cancelled) {
    QFile f(path);if(!f.open(QIODevice::ReadOnly)) throw std::runtime_error(("Cannot read "+path).toStdString());
    QCryptographicHash hash(QCryptographicHash::Sha256);
    while(!f.atEnd()) {if(cancelled->load()) throw std::runtime_error("Stopped.");const auto b=f.read(1024*1024);if(b.isEmpty()&&f.error()!=QFile::NoError) throw std::runtime_error("Read failed");hash.addData(b);}
    return hash.result().toHex();
}
static QByteArray engineHash(const Options& o,const std::shared_ptr<std::atomic_bool>& cancelled) {
    QStringList files={o.engine+"/VERSION",o.engine+"/run.py",o.engine+"/pixi.lock"};
    if(QFileInfo::exists(o.engine+"/settings.yaml")) files<<o.engine+"/settings.yaml";
    if(QFileInfo::exists(o.engine+"/SuperBuild/CMakeLists.txt")) files<<o.engine+"/SuperBuild/CMakeLists.txt";
    for(const auto& sub:{"stages","opendm","SuperBuild/cmake","fedora/finish","parallel_runtime"}) {
        QDirIterator it(o.engine+"/"+sub,{"*.py","*.cmake","*.patch","*.cpp","*.h"},QDir::Files,QDirIterator::Subdirectories);
        while(it.hasNext()) files<<it.next();
    }
    if(QFileInfo::exists(o.engine+"/fedora/engine-build.sha256")) files<<o.engine+"/fedora/engine-build.sha256";
    for(const auto& runner:{"quality_run.py","opensfm_runner.py","terrain_runtime.py"}) if(QFileInfo::exists(o.engine+"/fedora/"+runner)) files<<o.engine+"/fedora/"+runner;
    files.sort();QCryptographicHash hash(QCryptographicHash::Sha256);
    hash.addData(qgetenv("ODM_HYBRID")=="1" ? "hybrid=1" : "hybrid=0");
    for(const auto& file:files) {hash.addData(QDir(o.engine).relativeFilePath(file).toUtf8());hash.addData(fileHash(file,cancelled));}
    return hash.result().toHex();
}
static QString safeName(const QString& path,int index,QSet<QString>& used) {
    QString name=QFileInfo(path).fileName();name.replace(QRegularExpression("[^A-Za-z0-9_.-]"),"_");
    while(used.contains(name.toLower())) name=QString::number(index).rightJustified(6,'0')+"_"+name;
    used.insert(name.toLower());return name;
}
static QJsonObject prepare(const Options& o,const QJsonObject& old,const std::shared_ptr<std::atomic_bool>& cancel) {
    try {
        const auto files=imagesIn(o.input);if(files.size()<3) return {{"error","At least three overlapping photos are required."}};
        const auto engine=QString::fromLatin1(engineHash(o,cancel));
        if(old.contains("engine_sha256")&&old["engine_sha256"].toString()!=engine) return {{"error","The ODM engine changed. Choose a new project folder to preserve previous results."}};
        QJsonArray manifest;QCryptographicHash all(QCryptographicHash::Sha256);QSet<QString> used;QSet<QByteArray> hashes;
        all.addData(QByteArray("deduplicate-then-every-sixth-v1"));
        int unique=0,duplicates=0;
        for(int i=0;i<files.size();++i) {
            const auto& file=files[i];const auto hash=fileHash(file,cancel);
            const auto relative=QDir(o.input).relativeFilePath(file);all.addData(relative.toUtf8());all.addData(hash);
            if(hashes.contains(hash)){++duplicates;continue;}hashes.insert(hash);
            if(unique++%6!=0) continue;
            manifest.append(QJsonObject{{"source",file},{"name",safeName(file,i,used)},{"sha256",QString::fromLatin1(hash)}});
        }
        if(manifest.size()<3) return {{"error","Not enough photos after filtering. At least 13 unique photos are needed to keep images 1, 7 and 13."}};
        const auto inputHash=QString::fromLatin1(all.result().toHex());
        if(old.contains("input_sha256")&&old["input_sha256"].toString()!=inputHash) return {{"error","The source photos changed. Choose a new project folder; the old results are preserved."}};
        const auto snapshot=readJson(o.output+"/input-manifest.json");
        if(!snapshot.isEmpty()&&(snapshot["input_sha256"].toString()!=inputHash||snapshot["engine_sha256"].toString()!=engine))
            return {{"error","Photos or engine changed since this project was prepared. Choose a new project folder."}};
        const QJsonObject planned={{"input_sha256",inputHash},{"engine_sha256",engine},{"photos",manifest},{"photo_count",manifest.size()},{"source_count",files.size()},{"duplicate_count",duplicates},{"unique_count",unique},{"keep_every",6}};
        if(!writeJson(o.output+"/input-manifest.json",planned)) throw std::runtime_error("Cannot save the photo manifest");
        const auto images=o.output+"/flight/images";if(!QDir().mkpath(images)) throw std::runtime_error("Cannot create the image workspace");
        for(const auto& staged:QDir(images).entryList(QDir::Files|QDir::Hidden))
            if(!used.contains(staged.toLower())) throw std::runtime_error("Unexpected file in the staged photo folder. Choose a new project folder.");
        for(const auto& value:manifest) {
            if(cancel->load()) throw std::runtime_error("Stopped.");
            const auto record=value.toObject();const auto target=images+"/"+record["name"].toString();
            if(QFileInfo::exists(target)&&QString::fromLatin1(fileHash(target,cancel))==record["sha256"].toString()) continue;
            QFile input(record["source"].toString());QSaveFile output(target);QCryptographicHash copied(QCryptographicHash::Sha256);
            if(!input.open(QIODevice::ReadOnly)||!output.open(QIODevice::WriteOnly)) throw std::runtime_error("Cannot copy photos into the project");
            while(!input.atEnd()) {
                if(cancel->load()) throw std::runtime_error("Stopped.");const auto bytes=input.read(1024*1024);
                if(bytes.isEmpty()&&input.error()!=QFile::NoError) throw std::runtime_error("Photo read failed");
                copied.addData(bytes);if(output.write(bytes)!=bytes.size()) throw std::runtime_error("Photo copy failed: check free disk space");
            }
            if(QString::fromLatin1(copied.result().toHex())!=record["sha256"].toString()) throw std::runtime_error("A photo changed while being copied. Retry after the copy into the source folder finishes.");
            if(!output.commit()) throw std::runtime_error("Cannot commit the copied photo");
        }
        return planned;
    }catch(const std::exception& e) {return {{"error",QString::fromUtf8(e.what())}};}
}
Pipeline::Pipeline(QObject* parent):QObject(parent) {
    process.setProcessChannelMode(QProcess::MergedChannels);
    connect(&process,&QProcess::readyReadStandardOutput,this,&Pipeline::drain);
    connect(&process,&QProcess::errorOccurred,this,[this](QProcess::ProcessError e){if(e==QProcess::FailedToStart) finish(false,process.errorString());});
    connect(&process,qOverload<int,QProcess::ExitStatus>(&QProcess::finished),this,[this](int code,QProcess::ExitStatus exit) {
        drain();if(!active) return;
        if(stopping) {
#ifdef Q_OS_UNIX
            signalProcesses(stoppedChildren,SIGKILL);
#endif
            finish(false,"Stopped. Start again to resume from the interrupted stage.");return;
        }
        const auto result=readJson(options.output+"/flight/log.json");
        const QFileInfo tif(options.output+"/flight/odm_orthophoto/odm_orthophoto.tif");
        const QFileInfo fsr(options.output+"/flight/odm_orthophoto/odm_orthophoto_fsr2x.tif");
        if(code!=0||exit!=QProcess::NormalExit||!result["success"].toBool()||!tif.exists()||!tif.size()||!fsr.exists()||!fsr.size()) {
            const auto detail=result["error"].toObject()["message"].toString();
            finish(false,detail.isEmpty()?"ODM processing failed. The processing log contains the engine error.":detail);return;
        }
        QImageReader reader(options.output+"/flight/opensfm/stats/ortho.png");
        // PNG decoding may allocate the full raster before scaling; bound preview memory.
        if(reader.canRead()&&qint64(reader.size().width())*reader.size().height()<=32000000) {const auto size=reader.size();reader.setScaledSize(size.scaled(1400,1400,Qt::KeepAspectRatio));const auto image=reader.read();if(!image.isNull()) image.save(options.output+"/preview.jpg","JPG",92);}
        stage.clear();finish(true,"Orthophoto ready · ultra ODM reconstruction + FSR export.");
    });
    if(progressSocket.bind(QHostAddress::LocalHost,6367,QUdpSocket::ShareAddress|QUdpSocket::ReuseAddressHint))
        connect(&progressSocket,&QUdpSocket::readyRead,this,[this] {
            while(progressSocket.hasPendingDatagrams()) {
                QByteArray data;data.resize(int(progressSocket.pendingDatagramSize()));progressSocket.readDatagram(data.data(),data.size());
                const auto parts=data.split('/');
                if(active&&parts.size()==4&&parts[0]=="PGUP"&&parts[1].toLongLong()==process.processId()) {
                    bool ok;const auto p=parts[3].toDouble(&ok);
                    const int i=stages.indexOf(stage);if(ok&&std::isfinite(p)) emit status(i>=0?labels[i]:"Processing",qBound(0,int(p),100),100);
                }
            }
        });
}
Pipeline::~Pipeline() {
    if(cancelled) cancelled->store(true);
    if(process.state()!=QProcess::NotRunning) {
        stoppedChildren=descendants(process.processId());process.terminate();process.waitForFinished(1000);
#ifdef Q_OS_UNIX
        signalProcesses(stoppedChildren,SIGKILL);
#endif
        process.kill();process.waitForFinished(1000);
    }
}
void Pipeline::start(const Options& o) {
    if(active) return;const auto error=validate(o);if(!error.isEmpty()){emit finished(false,error);return;}
    options=o;options.threads=effectiveThreads(o.threads);options.input=resolved(o.input);options.engine=resolved(o.engine);options.output=resolved(o.output);
    if(!QDir().mkpath(options.output)){emit finished(false,"Cannot create the project folder.");return;}
    lock=std::make_unique<QLockFile>(options.output+"/.odm-desktop.lock");lock->setStaleLockTime(0);
    if(!lock->tryLock()){lock.reset();emit finished(false,"This project is running in another window.");return;}
    report=readJson(options.output+"/project.json");
    auto contents=QDir(options.output).entryList(QDir::AllEntries|QDir::NoDotAndDotDot|QDir::Hidden);contents.removeAll(".odm-desktop.lock");
    if(report.isEmpty()&&!contents.isEmpty()) {lock.reset();emit finished(false,"Choose an empty folder or a saved ODM Desktop project.");return;}
    if(!report.isEmpty()&&report["application"].toString()!="odm-fedora") {lock.reset();emit finished(false,"This folder belongs to a different application.");return;}
    const QJsonObject old=report;
    active=true;stopping=false;prepared=false;stage.clear();pendingLog.clear();timer.start();cancelled=std::make_shared<std::atomic_bool>(false);
    if(report.isEmpty()) {
        report={{"application","odm-fedora"},{"input",options.input},{"state","preparing"}};
        if(!writeJson(options.output+"/project.json",report)){active=false;lock.reset();emit finished(false,"Cannot save the project.");return;}
    }
    emit status("Check and prepare photos…",0,100);
    auto* watcher=new QFutureWatcher<QJsonObject>(this);
    connect(watcher,&QFutureWatcher<QJsonObject>::finished,this,[this,watcher,old] {
        const auto value=watcher->result();watcher->deleteLater();
        if(stopping){finish(false,"Stopped during photo preparation.");return;}
        if(value.contains("error")){finish(false,value["error"].toString());return;}
        for(auto i=value.begin();i!=value.end();++i) report[i.key()]=i.value();
        emit log(QString("Folder: %1 photos, %2 exact duplicates removed, %3 selected (1, 7, 13, …).\n").arg(value["source_count"].toInt()).arg(value["duplicate_count"].toInt()).arg(value["photo_count"].toInt()));
        rerun.clear();
        if(QStringList{"stopped","failed","running"}.contains(old["state"].toString())) rerun=old["stage"].toString();
        if(!stages.contains(rerun)) rerun.clear();
        if(old.contains("resolution")&&old["resolution"].toDouble()!=options.resolution) {
            const auto exportStage=QString("odm_orthophoto");if(rerun.isEmpty()||stages.indexOf(rerun)>stages.indexOf(exportStage)) rerun=exportStage;
        }
        prepared=true;report["input"]=options.input;report["threads"]=options.threads;report["resolution"]=options.resolution;
        stage=rerun;save("running");launch();
    });
    const auto copy=options;const auto cancel=cancelled;
    watcher->setFuture(QtConcurrent::run([copy,old,cancel]{return prepare(copy,old,cancel);}));
}
void Pipeline::launch() {
    logFile.setFileName(options.output+"/processing.log");
    if(!logFile.open(QIODevice::WriteOnly|QIODevice::Append)){finish(false,"Cannot write the processing log.");return;}
    logFile.write(("\nODM Desktop · "+QDateTime::currentDateTimeUtc().toString(Qt::ISODate)+"\n").toUtf8());
    process.setWorkingDirectory(options.engine);process.setProcessEnvironment(engineEnvironment(options));
    report["command"]=QJsonArray::fromStringList(arguments(options,rerun));save("running");
    emit log("Quality: DSPSIFT/ultra, 24,000 features, ultra dense cloud; FSR1 display export. Full terrain reconstruction and map surface texturing.\n");
    process.start(pythonPath(options),arguments(options,rerun));
}
void Pipeline::drain() {
    const auto bytes=process.readAllStandardOutput();if(logFile.isOpen()){logFile.write(bytes);logFile.flush();}
    const auto text=QString::fromUtf8(bytes);emit log(text);pendingLog+=text;
    const QRegularExpression re("Running (\\w+) stage");
    int newline;
    while((newline=pendingLog.indexOf('\n'))>=0) {
        const auto line=pendingLog.left(newline);pendingLog.remove(0,newline+1);const auto match=re.match(line);
        if(match.hasMatch()) {stage=match.captured(1);const int i=stages.indexOf(stage);if(i>=0) emit status(labels[i],i*100/stages.size(),100);save("running");}
    }
    if(pendingLog.size()>65536) pendingLog=pendingLog.right(4096);
}
void Pipeline::save(const QString& state,const QString& message) {
    if(!prepared) return;
    report["state"]=state;report["stage"]=stage;report["message"]=message;
    report["last_run_seconds"]=timer.elapsed()/1000.0;report["updated"]=QDateTime::currentDateTimeUtc().toString(Qt::ISODate);
    if(!writeJson(options.output+"/project.json",report)) emit log("Could not save project state. Check free disk space.\n");
}
void Pipeline::finish(bool ok,const QString& message) {
    if(!active) return;
    save(ok?"complete":stopping?"stopped":"failed",message);active=false;logFile.close();lock.reset();
    emit status(message,ok?100:0,100);emit finished(ok,message);
}
void Pipeline::cancel() {
    if(!active||stopping) return;stopping=true;cancelled->store(true);
    if(process.state()!=QProcess::NotRunning) {
        stoppedChildren=descendants(process.processId());process.terminate();
        // ODM's own TERM handler stops its process groups. Kill any surviving,
        // identity-checked descendants afterwards, even if the Python parent exited.
        const auto children=stoppedChildren;const auto cancellation=cancelled;
        QTimer::singleShot(3000,this,[this,children,cancellation] {
#ifdef Q_OS_UNIX
            signalProcesses(children,SIGKILL);
#endif
            if(cancelled==cancellation&&stopping&&process.state()!=QProcess::NotRunning) process.kill();
        });
    }
}
}
