#pragma once
#include <QtCore>
namespace odm {
struct ProcessIdentity { qint64 pid, born; };
QList<ProcessIdentity> descendants(qint64 parent);
void signalProcesses(const QList<ProcessIdentity>& processes, int signal);
}
