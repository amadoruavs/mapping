# Applied inside each native dependency project (including existing build caches).
# Build on the destination laptop: this intentionally targets its actual CPU ISA.
if(CMAKE_SYSTEM_NAME STREQUAL "Linux" AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|AMD64")
  foreach(lang C CXX)
    if(CMAKE_${lang}_COMPILER_ID MATCHES "GNU|Clang")
      set(CMAKE_${lang}_FLAGS_RELEASE "-O3 -DNDEBUG -march=native -mtune=native -fno-math-errno" CACHE STRING "Host-tuned release flags" FORCE)
    endif()
  endforeach()
endif()
