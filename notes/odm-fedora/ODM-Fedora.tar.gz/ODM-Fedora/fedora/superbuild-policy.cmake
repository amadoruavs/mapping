# Reuse existing source checkouts; preserve the versions selected by ODM.
set_property(DIRECTORY PROPERTY EP_UPDATE_DISCONNECTED TRUE)
