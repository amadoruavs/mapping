#!/usr/bin/env bash
set -euo pipefail
odm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if [[ "$(uname -s)" != Linux ]]; then printf '%s\n' 'This launcher is for Fedora Linux.' >&2; exit 1; fi
if [[ ! -x "$odm_root/fedora/build/odm-native" || ! -x "$odm_root/.pixi/envs/default/bin/python" ]]; then
  printf '%s\n' 'Run ./install-fedora.sh first.' >&2; exit 1
fi
export ODM_ENGINE_ROOT="$odm_root"
# The desktop uses Fedora Qt; only its engine subprocess uses the pixi libraries.
unset LD_LIBRARY_PATH QT_PLUGIN_PATH QT_QPA_PLATFORM_PLUGIN_PATH PYTHONHOME PYTHONPATH
if [[ $# == 0 ]]; then set -- --serve; fi
exec "$odm_root/fedora/build/odm-native" "$@"
