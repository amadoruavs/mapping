#!/usr/bin/env bash
set -euo pipefail
odm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
[[ "$(uname -s)" == Darwin ]] || { echo 'Use run-fedora.sh on Linux.' >&2; exit 1; }
[[ -x "$odm_root/.pixi/envs/default/bin/python" && -x "$odm_root/fedora/build/odm-native" && -x "$odm_root/SuperBuild/install/bin/DensifyPointCloud" ]] || {
  echo 'Run ./install-macos.sh first.' >&2; exit 1;
}
export ODM_ENGINE_ROOT="$odm_root"
export ODM_FSR_BACKEND=cpu
unset LD_LIBRARY_PATH DYLD_LIBRARY_PATH QT_PLUGIN_PATH QT_QPA_PLATFORM_PLUGIN_PATH PYTHONHOME PYTHONPATH
if [[ $# == 0 ]]; then set -- --serve --port 8767; fi
exec "$odm_root/fedora/build/odm-native" "$@"
