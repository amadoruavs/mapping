#!/usr/bin/env bash
set -euo pipefail
odm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$odm_root"
odm_python="$odm_root/.pixi/envs/default/bin/python"
[[ -x "$odm_python" ]] || { echo 'Run the platform installer first.' >&2; exit 1; }
mkdir -p fedora/validation/target
"$odm_python" -m parallel_runtime.doctor --output fedora/validation/target/hardware.json
"$odm_python" -m unittest parallel_runtime.test_scheduler parallel_runtime.test_pixels parallel_runtime.test_native
"$odm_python" -m unittest discover -s fedora/tests -p test_terrain_runtime.py
odm_error_report="$(mktemp -d "$odm_root/fedora/validation/target/high-error-XXXXXX")"
"$odm_python" fedora/validate_high_error.py --output "$odm_error_report/results"
"$odm_python" fedora/finish/validate.py --output fedora/validation/target/fsr-cpu.json
"$odm_python" fedora/finish/validate_math.py fedora/validation/target/hip-host-math.json
case "${1:-cpu}" in
 cpu) ;;
 native-hip|xdna)
  [[ "$1" != native-hip ]] || bash parallel_runtime/kernels/build-hip.sh
  "$odm_python" -m parallel_runtime.validate_native --backend "$1" --output "validation/target/$1.json"
  ;;
 hip)
  ./fedora/finish/build-hip.sh
  "$odm_python" fedora/finish/validate.py --hip --output fedora/validation/target/fsr-hip.json
  ;;
 metal|hip-python)
  backend=metal
  [[ "$1" != hip-python ]] || backend=hip
  "$odm_python" -m parallel_runtime.validate --backend "$backend" --output "fedora/validation/target/pixels-$backend.json"
  ;;
 *) echo 'Usage: ./verify-acceleration.sh [cpu|hip|metal|hip-python|native-hip|xdna]' >&2; exit 2 ;;
esac
