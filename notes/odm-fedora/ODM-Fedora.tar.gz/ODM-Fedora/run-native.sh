#!/usr/bin/env bash
set -euo pipefail
odm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
exec "$odm_root/run-fedora.sh" "$@"
