import unittest
from types import SimpleNamespace
from unittest.mock import patch
from opendm import concurrency


class MeshMemoryTests(unittest.TestCase):
    def test_limits_ram_without_changing_quality(self):
        for available_gib, requested, expected in [(32, 20, 9), (8, 20, 2), (1, 20, 1), (32, 4, 4)]:
            with self.subTest(available_gib=available_gib, requested=requested):
                with patch.object(concurrency, "virtual_memory", return_value=SimpleNamespace(available=available_gib * 1024**3)), patch.object(concurrency.os, "cpu_count", return_value=20):
                    self.assertEqual(concurrency.mesh_workers(requested), expected)

    def test_limits_cpu(self):
        with patch.object(concurrency, "virtual_memory", return_value=SimpleNamespace(available=128 * 1024**3)), patch.object(concurrency.os, "cpu_count", return_value=12):
            self.assertEqual(concurrency.mesh_workers(20), 12)
