#!/usr/bin/env bash
# Build the original ODM engine and a Qt/C++ desktop application, without containers.
set -euo pipefail
odm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
case "${1:-}" in
  --help|-h)
    printf '%s\n' 'Usage: ./install-fedora.sh [--check|--offline]' 'Run as your regular Fedora user. Only missing system packages use sudo.' '--offline checks an already built engine and rebuilds the interface without downloads.' 'Optional: ODM_BUILD_JOBS=2, ODM_SKIP_SYSTEM_DEPS=1.'
    exit 0 ;;
  ''|--check|--offline) ;;
  *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
esac
if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
  printf '%s\n' 'This installer targets Fedora Linux on x86_64 (AMD or Intel).' >&2; exit 1
fi
source /etc/os-release
if [[ "${ID:-}" != fedora ]]; then
  printf '%s\n' 'This installer targets Fedora. Other distributions need their own system package setup.' >&2; exit 1
fi
if [[ ! "$odm_root" =~ ^[/A-Za-z0-9_.-]+$ ]]; then
  printf '%s\n' 'Extract into a path containing only letters, numbers, /, _, - and dots, such as ~/Applications/ODM-Fedora.' >&2; exit 1
fi
if [[ "${1:-}" == --check ]]; then
  printf 'System: %s\nArchitecture: %s\nLogical CPUs: %s\n' "$PRETTY_NAME" "$(uname -m)" "$(getconf _NPROCESSORS_ONLN)"
  free -h
  df -h "$odm_root"
  printf '%s\n' 'Reconstruction: host-tuned parallel CPU. FSR: optional HIP gfx1150 with CPU fallback.'
  for odm_tool in dnf git curl cmake g++; do
    if command -v "$odm_tool" >/dev/null; then printf 'Found: %s\n' "$odm_tool"; else printf 'Installer will need: %s\n' "$odm_tool"; fi
  done
  exit 0
fi
if (( EUID == 0 )); then printf '%s\n' 'Run this script as your regular user, without sudo. It requests sudo for system packages.' >&2; exit 1; fi
if [[ -n "${CONDA_PREFIX:-}" ]]; then printf '%s\n' 'Leave your active conda/pixi shell before installation; the desktop uses Fedora Qt.' >&2; exit 1; fi
odm_jobs="${ODM_BUILD_JOBS:-2}"
if [[ ! "$odm_jobs" =~ ^[1-8]$ ]]; then printf '%s\n' 'ODM_BUILD_JOBS must be 1 to 8. Default 2 limits nested compiler memory use.' >&2; exit 1; fi
exec > >(tee -a "$odm_root/fedora-install.log") 2>&1
trap 'printf "Installation stopped at line %s. See fedora-install.log; rerun to continue.\n" "$LINENO" >&2' ERR
odm_packages=(gcc-c++ cmake make git curl tar gzip xz ca-certificates qt6-qtbase-devel util-linux)
odm_missing=()
for odm_package in "${odm_packages[@]}"; do rpm -q "$odm_package" >/dev/null 2>&1 || odm_missing+=("$odm_package"); done
if (( ${#odm_missing[@]} )); then
  if [[ "${1:-}" == --offline ]]; then printf 'Offline setup needs installed system packages: %s\n' "${odm_missing[*]}" >&2; exit 1; fi
  if [[ "${ODM_SKIP_SYSTEM_DEPS:-0}" != 1 ]]; then sudo dnf install -y --setopt=install_weak_deps=False "${odm_missing[@]}"; fi
fi
mkdir -p "$odm_root/.local-tools"
exec 9>"$odm_root/.local-tools/install.lock"
flock -n 9 || { printf '%s\n' 'Another installer is already running.' >&2; exit 1; }
odm_pixi="$odm_root/.local-tools/pixi"
cd "$odm_root"
odm_native_needed=1
odm_signature="$(sha256sum pixi.lock SuperBuild/CMakeLists.txt SuperBuild/cmake/* fedora/superbuild-policy.cmake fedora/native-tuning.cmake)"
if [[ -f fedora/engine-ready.txt && -x .pixi/envs/default/bin/python && -x SuperBuild/install/bin/odm_orthophoto ]]; then
  if [[ "$(cat fedora/engine-ready.txt)" == "$odm_signature" ]]; then odm_native_needed=0; fi
fi
if [[ "${1:-}" == --offline && "$odm_native_needed" == 1 ]]; then
  printf '%s\n' 'The native engine must be installed once while online. Offline mode cannot fetch missing dependencies.' >&2; exit 1
fi
if [[ "$odm_native_needed" == 1 ]]; then
if [[ ! -x "$odm_pixi" ]] || [[ "$("$odm_pixi" --version)" != 'pixi 0.77.1' ]]; then
  printf '%s\n' 'Downloading Pixi 0.77.1 (local native package manager)…'
  odm_download="$odm_root/.local-tools/pixi-linux.tar.gz"
  curl --fail --location --retry 3 --proto '=https' --tlsv1.2 \
    https://github.com/prefix-dev/pixi/releases/download/v0.77.1/pixi-x86_64-unknown-linux-musl.tar.gz -o "$odm_download"
  printf '%s  %s\n' '74dbe15255c763396ac847eb455573c6400e9caf06614c3fc00cb3de6d1099d5' "$odm_download" | sha256sum --check --status
  tar -xzf "$odm_download" -C "$odm_root/.local-tools" pixi
fi
cd "$odm_root"
printf '%s\n' 'Installing locked native dependencies…'
"$odm_pixi" install --locked -e default
printf '%s\n' 'Building ODM. The first installation downloads and compiles its native engines.'
export CMAKE_BUILD_PARALLEL_LEVEL="$odm_jobs"
export ODM_ENABLE_CUDA=OFF
"$odm_pixi" run --locked -e default cmake -S SuperBuild -B SuperBuild/build \
  "-DCMAKE_PROJECT_INCLUDE=$odm_root/fedora/superbuild-policy.cmake"
"$odm_pixi" run --locked -e default cmake --build SuperBuild/build --target \
  opensfm openmvs mvstexturing fpcfilter dem2mesh odm_orthophoto fastrasterfilter renderdem
"$odm_pixi" run --locked -e default smoke
# Fingerprint installed programs so a rebuild cannot silently reuse an old reconstruction.
find SuperBuild/install -type f \( -perm /111 -o -name '*.so*' \) -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum > fedora/engine-build.sha256.tmp
mv fedora/engine-build.sha256.tmp fedora/engine-build.sha256
printf '%s\n' "$odm_signature" > fedora/engine-ready.txt
else
  printf '%s\n' 'Reusing the installed ODM engine. No dependency downloads.'
fi
printf '%s\n' 'Building FSR CPU kernels for this laptop…'
"${CXX:-g++}" -std=c++17 -O3 -march=native -mtune=native -fno-math-errno -ffp-contract=off -fopenmp-simd -pthread -shared -fPIC \
  -fopt-info-vec-optimized="$odm_root/fedora/finish/vectorization.txt" \
  "$odm_root/fedora/finish/native.cpp" -o "$odm_root/fedora/finish/libfsr_cpu.so"
if command -v hipcc >/dev/null || [[ -x /opt/rocm/bin/hipcc ]]; then
  if ! "$odm_root/fedora/finish/build-hip.sh"; then printf '%s\n' 'HIP build failed; FSR will use the CPU. See fedora-install.log.'; fi
else
  printf '%s\n' 'Optional HIP FSR: sudo dnf install rocm-hip-devel; then ./fedora/finish/build-hip.sh'
fi
if command -v hipcc >/dev/null || [[ -x /opt/rocm/bin/hipcc ]]; then
  if bash "$odm_root/parallel_runtime/kernels/build-hip.sh"; then
    if ! timeout 300 "$odm_root/.pixi/envs/default/bin/python" -m parallel_runtime.validate_native --backend native-hip --output validation/target/native-hip.json; then
      mv "$odm_root/parallel_runtime/kernels/libadm_hip.so" "$odm_root/parallel_runtime/kernels/libadm_hip.so.failed"
      echo 'Custom HIP check failed; CPU fallback enabled. See validation/target/native-hip.json.'
    fi
  else
    echo 'Custom HIP build failed; CPU fallback enabled.'
  fi
fi
printf '%s\n' 'Building and checking the C++ desktop…'  
cmake -S fedora -B fedora/build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build fedora/build --parallel "$odm_jobs"
ctest --test-dir fedora/build --output-on-failure
"$odm_root/fedora/build/odm-native" --doctor --engine "$odm_root"
odm_applications="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$odm_applications"
cat > "$odm_applications/odm-fedora.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=ODM Flight Line
Comment=Create orthophotos locally with OpenDroneMap
Exec="$odm_root/run-fedora.sh"
Icon=applications-science
Terminal=true
Categories=Science;Geography;
StartupNotify=true
EOF
printf '\n%s\n' 'Ready. Run ./run-fedora.sh and open http://127.0.0.1:8765' 'Flight-line use is offline. Keep this terminal running.'
