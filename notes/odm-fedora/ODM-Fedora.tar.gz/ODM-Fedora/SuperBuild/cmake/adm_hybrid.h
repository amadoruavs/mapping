#pragma once
#include "adm_flat.h"
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <vector>
#if defined(__linux__)
#include <dlfcn.h>
#endif
inline bool adm_hybrid_enabled() {
    const char* value=std::getenv("ODM_HYBRID");
    return value && std::strcmp(value,"1")==0;
}
inline std::vector<uint8_t> adm_hybrid_mask(const float* d,const float* c,int w,int h) {
    std::vector<uint8_t> mask(size_t((w+31)/32)*((h+31)/32));
    adm_flat_cpu(d,c,w,h,mask.data());
#if defined(__linux__)
    // Compare every GPU classification to the CPU decision. Even a single
    // threshold disagreement rejects the GPU mask. This is a validation path;
    // the small classifier is not the reconstruction's dominant cost.
    const char* path=std::getenv("ADM_HIP_KERNEL_LIBRARY");
    if(path && *path) {
        using Fn=int(*)(const float*,const float*,int,int,uint8_t*);
        static void* library=dlopen(path,RTLD_LOCAL|RTLD_NOW);
        static Fn fn=library?reinterpret_cast<Fn>(dlsym(library,"adm_flat_tiles")):nullptr;
        if(fn) {
            std::vector<uint8_t> gpu(mask.size());
            if(fn(d,c,w,h,gpu.data())==0 && gpu==mask) return gpu;
        }
    }
#endif
    return mask;
}
