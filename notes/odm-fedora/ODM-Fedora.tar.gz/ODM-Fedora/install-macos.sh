#!/usr/bin/env bash
# Apple Silicon native port: same ODM settings and engine as Fedora; CPU FSR.
set -euo pipefail
odm_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
[[ "$(uname -s)" == Darwin && "$(uname -m)" == arm64 ]] || { echo 'This installer targets Apple Silicon macOS.' >&2; exit 1; }
xcrun --find clang++ >/dev/null || { echo 'Install Xcode command line tools first: xcode-select --install' >&2; exit 1; }
command -v brew >/dev/null || { echo 'Homebrew is required for the Qt interface.' >&2; exit 1; }
if [[ ! -d "$(brew --prefix)/lib/cmake/Qt6" ]]; then brew install qtbase; fi
command -v cmake >/dev/null || brew install cmake
cd "$odm_root"
mkdir -p .local-tools
export PIXI_CACHE_DIR="$odm_root/.local-tools/cache"
if [[ ! -x .local-tools/pixi ]]; then
  curl -fsSL https://github.com/prefix-dev/pixi/releases/download/v0.77.1/pixi-aarch64-apple-darwin.tar.gz -o .local-tools/pixi-macos.tar.gz
  printf '%s  %s\n' 2b1280f11ed058477eb2752baac875615eb9ad48002c0536d8063d4249e853c2 .local-tools/pixi-macos.tar.gz | shasum -a 256 -c -
  tar -xzf .local-tools/pixi-macos.tar.gz -C .local-tools pixi
fi
export CMAKE_BUILD_PARALLEL_LEVEL="${ODM_BUILD_JOBS:-6}"
export ODM_ENABLE_CUDA=OFF
.local-tools/pixi install --locked -e default
.local-tools/pixi run --locked -e default cmake -S SuperBuild -B SuperBuild/build -DCMAKE_BUILD_TYPE=Release \
  "-DCMAKE_PROJECT_INCLUDE=$odm_root/fedora/superbuild-policy.cmake"
.local-tools/pixi run --locked -e default cmake --build SuperBuild/build --target \
  opensfm openmvs mvstexturing fpcfilter dem2mesh odm_orthophoto fastrasterfilter renderdem --parallel "$CMAKE_BUILD_PARALLEL_LEVEL"
.local-tools/pixi run --locked -e default python scripts/smoke.py
cmake -S fedora -B fedora/build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON "-DCMAKE_PREFIX_PATH=$(brew --prefix)"
cmake --build fedora/build --parallel "$CMAKE_BUILD_PARALLEL_LEVEL"
ctest --test-dir fedora/build --output-on-failure
printf '%s\n' 'Ready: ./run-macos.sh -> http://127.0.0.1:8767'
